﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmAdminAddSelectExam : Form
    {
        public frmAdminAddSelectExam()
        {
            InitializeComponent();
        }  
        public string Timu="";
        public string DaanA = "";
        public string DaanB = "";
        public string DaanC = "";
        public string DaanD = "";
        public string ZQDaan = "";
        public int mid;
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtDaAnA.Text.Trim() == "" || txtDaAnB.Text.Trim() == "" || txtDaAnC.Text.Trim() == "" || txtDaAnD.Text.Trim() == "" || txtRightDaAn.Text.Trim() == "" || txtTimu.Text.Trim() == "")
            {
                MessageBox.Show("提示：将信息填写完整！");
            }
            else if(Timu!=""|| DaanA != ""|| DaanB!= ""|| DaanC!= ""|| DaanD!= "" || ZQDaan != "")
            {
                string sql = "update tb_Test set subject='" + txtTimu.Text.Trim() + "',rightkey='" + txtRightDaAn.Text.Trim().ToUpper() + "',A='" + txtDaAnA.Text.Trim() + "',B='" + txtDaAnB.Text.Trim() + "',C='" + txtDaAnC.Text.Trim() + "',D='" + txtDaAnD.Text.Trim() + "' where ID=" + mid;
                BassClass.UpdateData(sql);
                this.Close();
            }
            else
            {
                string sql = "insert into tb_Test(TypeID,subject,rightkey,A,B,C,D) values(1,'" 
                    + txtTimu.Text.Trim() + "','" + txtRightDaAn.Text.Trim().ToUpper() + "','" + txtDaAnA.Text.Trim() + "','" + txtDaAnB.Text.Trim() + "','" + txtDaAnC.Text.Trim() + "','" + txtDaAnD.Text.Trim() + "')";
                BassClass.InsertData(sql);
                txtDaAnA.Text = "";
                txtDaAnB.Text = "";
                txtDaAnC.Text = "";
                txtDaAnD.Text = "";
                txtRightDaAn.Text = "";
                txtTimu.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAdminAddSelectExam_Load(object sender, EventArgs e)
        {
            txtDaAnA.Text = DaanA;
            txtDaAnB.Text = DaanB;
            txtDaAnC.Text = DaanC;
            txtDaAnD.Text = DaanD;
            txtRightDaAn.Text = ZQDaan;
            txtTimu.Text = Timu;
        }
    }
}
