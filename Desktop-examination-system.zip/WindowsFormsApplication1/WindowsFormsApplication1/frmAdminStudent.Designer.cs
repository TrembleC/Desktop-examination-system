﻿namespace WindowsFormsApplication1
{
    partial class frmAdminStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.refresh = new System.Windows.Forms.Button();
            this.Delete_user = new System.Windows.Forms.Button();
            this.Update_user = new System.Windows.Forms.Button();
            this.Add_user = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.refresh);
            this.groupBox1.Controls.Add(this.Delete_user);
            this.groupBox1.Controls.Add(this.Update_user);
            this.groupBox1.Controls.Add(this.Add_user);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Location = new System.Drawing.Point(0, 420);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(943, 144);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本操作";
            // 
            // refresh
            // 
            this.refresh.BackColor = System.Drawing.Color.LightGray;
            this.refresh.Location = new System.Drawing.Point(805, 60);
            this.refresh.Name = "refresh";
            this.refresh.Size = new System.Drawing.Size(97, 47);
            this.refresh.TabIndex = 3;
            this.refresh.Text = "刷新";
            this.refresh.UseVisualStyleBackColor = false;
            this.refresh.Click += new System.EventHandler(this.refresh_Click);
            // 
            // Delete_user
            // 
            this.Delete_user.BackColor = System.Drawing.Color.LightGray;
            this.Delete_user.Location = new System.Drawing.Point(549, 60);
            this.Delete_user.Name = "Delete_user";
            this.Delete_user.Size = new System.Drawing.Size(97, 47);
            this.Delete_user.TabIndex = 2;
            this.Delete_user.Text = "删除用户";
            this.Delete_user.UseVisualStyleBackColor = false;
            this.Delete_user.Click += new System.EventHandler(this.Delete_user_Click);
            // 
            // Update_user
            // 
            this.Update_user.BackColor = System.Drawing.Color.LightGray;
            this.Update_user.Location = new System.Drawing.Point(293, 60);
            this.Update_user.Name = "Update_user";
            this.Update_user.Size = new System.Drawing.Size(97, 47);
            this.Update_user.TabIndex = 1;
            this.Update_user.Text = "修改用户";
            this.Update_user.UseVisualStyleBackColor = false;
            this.Update_user.Click += new System.EventHandler(this.Update_user_Click);
            // 
            // Add_user
            // 
            this.Add_user.BackColor = System.Drawing.Color.LightGray;
            this.Add_user.Location = new System.Drawing.Point(37, 60);
            this.Add_user.Name = "Add_user";
            this.Add_user.Size = new System.Drawing.Size(97, 47);
            this.Add_user.TabIndex = 0;
            this.Add_user.Text = "添加用户";
            this.Add_user.UseVisualStyleBackColor = false;
            this.Add_user.Click += new System.EventHandler(this.Add_user_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(943, 414);
            this.panel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(943, 414);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseUp);
            // 
            // frmAdminStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(943, 564);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmAdminStudent";
            this.Text = "用户管理";
            this.Load += new System.EventHandler(this.frmAdminStudent_Load);
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button refresh;
        private System.Windows.Forms.Button Delete_user;
        private System.Windows.Forms.Button Update_user;
        private System.Windows.Forms.Button Add_user;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}