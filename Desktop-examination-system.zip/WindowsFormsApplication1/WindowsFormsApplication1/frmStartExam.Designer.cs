﻿namespace WindowsFormsApplication1
{
    partial class frmStartExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gb_daan = new System.Windows.Forms.GroupBox();
            this.rb_D = new System.Windows.Forms.RadioButton();
            this.rb_C = new System.Windows.Forms.RadioButton();
            this.rb_B = new System.Windows.Forms.RadioButton();
            this.rb_A = new System.Windows.Forms.RadioButton();
            this.gb_timu = new System.Windows.Forms.GroupBox();
            this.txt_xztimu = new System.Windows.Forms.TextBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel6 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gb_pddaan = new System.Windows.Forms.GroupBox();
            this.rb_pddaan0 = new System.Windows.Forms.RadioButton();
            this.rb_pddaan1 = new System.Windows.Forms.RadioButton();
            this.gb_pdtimu = new System.Windows.Forms.GroupBox();
            this.txt_pdtimu = new System.Windows.Forms.TextBox();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel7 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.gb_tkdaan = new System.Windows.Forms.GroupBox();
            this.txt_tkdaan = new System.Windows.Forms.TextBox();
            this.gb_tktimu = new System.Windows.Forms.GroupBox();
            this.txt_tktimu = new System.Windows.Forms.TextBox();
            this.toolStrip5 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel5 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel8 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.tsltotal = new System.Windows.Forms.ToolStripLabel();
            this.tsl_totaltime = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel9 = new System.Windows.Forms.ToolStripLabel();
            this.tsl_used = new System.Windows.Forms.ToolStripLabel();
            this.tsl_usedtime = new System.Windows.Forms.ToolStripLabel();
            this.tsl_rest = new System.Windows.Forms.ToolStripLabel();
            this.tsl_resttime = new System.Windows.Forms.ToolStripLabel();
            this.toolStripLabel10 = new System.Windows.Forms.ToolStripLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.gb_daan.SuspendLayout();
            this.gb_timu.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.gb_pddaan.SuspendLayout();
            this.gb_pdtimu.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.gb_tkdaan.SuspendLayout();
            this.gb_tktimu.SuspendLayout();
            this.toolStrip5.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripLabel2,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(698, 27);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(33, 24);
            this.toolStripLabel1.Text = "……";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Margin = new System.Windows.Forms.Padding(100, 1, 0, 2);
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(33, 24);
            this.toolStripLabel2.Text = "……";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::WindowsFormsApplication1.Properties.Resources.accept;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Margin = new System.Windows.Forms.Padding(100, 1, 10, 2);
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton1.Text = "提交试卷";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(698, 631);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.gb_daan);
            this.tabPage1.Controls.Add(this.gb_timu);
            this.tabPage1.Controls.Add(this.toolStrip2);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(690, 602);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "选择题";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // gb_daan
            // 
            this.gb_daan.Controls.Add(this.rb_D);
            this.gb_daan.Controls.Add(this.rb_C);
            this.gb_daan.Controls.Add(this.rb_B);
            this.gb_daan.Controls.Add(this.rb_A);
            this.gb_daan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gb_daan.Location = new System.Drawing.Point(3, 211);
            this.gb_daan.Name = "gb_daan";
            this.gb_daan.Size = new System.Drawing.Size(684, 388);
            this.gb_daan.TabIndex = 2;
            this.gb_daan.TabStop = false;
            this.gb_daan.Text = "备选答案";
            // 
            // rb_D
            // 
            this.rb_D.AutoSize = true;
            this.rb_D.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_D.Location = new System.Drawing.Point(82, 271);
            this.rb_D.Name = "rb_D";
            this.rb_D.Size = new System.Drawing.Size(60, 23);
            this.rb_D.TabIndex = 3;
            this.rb_D.TabStop = true;
            this.rb_D.Text = "D- ";
            this.rb_D.UseVisualStyleBackColor = true;
            this.rb_D.CheckedChanged += new System.EventHandler(this.rb_D_CheckedChanged);
            // 
            // rb_C
            // 
            this.rb_C.AutoSize = true;
            this.rb_C.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_C.Location = new System.Drawing.Point(82, 204);
            this.rb_C.Name = "rb_C";
            this.rb_C.Size = new System.Drawing.Size(60, 23);
            this.rb_C.TabIndex = 2;
            this.rb_C.TabStop = true;
            this.rb_C.Text = "C- ";
            this.rb_C.UseVisualStyleBackColor = true;
            this.rb_C.CheckedChanged += new System.EventHandler(this.rb_C_CheckedChanged);
            // 
            // rb_B
            // 
            this.rb_B.AutoSize = true;
            this.rb_B.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_B.Location = new System.Drawing.Point(82, 137);
            this.rb_B.Name = "rb_B";
            this.rb_B.Size = new System.Drawing.Size(60, 23);
            this.rb_B.TabIndex = 1;
            this.rb_B.TabStop = true;
            this.rb_B.Text = "B- ";
            this.rb_B.UseVisualStyleBackColor = true;
            this.rb_B.CheckedChanged += new System.EventHandler(this.rb_B_CheckedChanged);
            // 
            // rb_A
            // 
            this.rb_A.AutoSize = true;
            this.rb_A.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_A.Location = new System.Drawing.Point(82, 70);
            this.rb_A.Name = "rb_A";
            this.rb_A.Size = new System.Drawing.Size(60, 23);
            this.rb_A.TabIndex = 0;
            this.rb_A.TabStop = true;
            this.rb_A.Text = "A- ";
            this.rb_A.UseVisualStyleBackColor = true;
            this.rb_A.CheckedChanged += new System.EventHandler(this.rb_A_CheckedChanged);
            // 
            // gb_timu
            // 
            this.gb_timu.Controls.Add(this.txt_xztimu);
            this.gb_timu.Dock = System.Windows.Forms.DockStyle.Top;
            this.gb_timu.Location = new System.Drawing.Point(3, 30);
            this.gb_timu.Name = "gb_timu";
            this.gb_timu.Size = new System.Drawing.Size(684, 181);
            this.gb_timu.TabIndex = 1;
            this.gb_timu.TabStop = false;
            this.gb_timu.Text = "题目：";
            // 
            // txt_xztimu
            // 
            this.txt_xztimu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_xztimu.Location = new System.Drawing.Point(3, 21);
            this.txt_xztimu.Multiline = true;
            this.txt_xztimu.Name = "txt_xztimu";
            this.txt_xztimu.Size = new System.Drawing.Size(678, 157);
            this.txt_xztimu.TabIndex = 0;
            // 
            // toolStrip2
            // 
            this.toolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel3,
            this.toolStripLabel6,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton8});
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(684, 27);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(122, 24);
            this.toolStripLabel3.Text = "toolStripLabel3";
            // 
            // toolStripLabel6
            // 
            this.toolStripLabel6.Name = "toolStripLabel6";
            this.toolStripLabel6.Size = new System.Drawing.Size(56, 24);
            this.toolStripLabel6.Text = "第 1 页";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::WindowsFormsApplication1.Properties.Resources.f060;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton2.Text = "上一页";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::WindowsFormsApplication1.Properties.Resources.right;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton3.Text = "下一页";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::WindowsFormsApplication1.Properties.Resources.btn_tijiao;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton8.Text = "保存";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.gb_pddaan);
            this.tabPage2.Controls.Add(this.gb_pdtimu);
            this.tabPage2.Controls.Add(this.toolStrip4);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(690, 602);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "判断题";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // gb_pddaan
            // 
            this.gb_pddaan.Controls.Add(this.rb_pddaan0);
            this.gb_pddaan.Controls.Add(this.rb_pddaan1);
            this.gb_pddaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gb_pddaan.Location = new System.Drawing.Point(3, 361);
            this.gb_pddaan.Name = "gb_pddaan";
            this.gb_pddaan.Size = new System.Drawing.Size(684, 238);
            this.gb_pddaan.TabIndex = 3;
            this.gb_pddaan.TabStop = false;
            this.gb_pddaan.Text = "备选答案：";
            // 
            // rb_pddaan0
            // 
            this.rb_pddaan0.AutoSize = true;
            this.rb_pddaan0.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_pddaan0.Location = new System.Drawing.Point(474, 115);
            this.rb_pddaan0.Name = "rb_pddaan0";
            this.rb_pddaan0.Size = new System.Drawing.Size(70, 24);
            this.rb_pddaan0.TabIndex = 1;
            this.rb_pddaan0.TabStop = true;
            this.rb_pddaan0.Text = "错误";
            this.rb_pddaan0.UseVisualStyleBackColor = true;
            this.rb_pddaan0.CheckedChanged += new System.EventHandler(this.rb_pddaan0_CheckedChanged);
            // 
            // rb_pddaan1
            // 
            this.rb_pddaan1.AutoSize = true;
            this.rb_pddaan1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rb_pddaan1.Location = new System.Drawing.Point(44, 115);
            this.rb_pddaan1.Name = "rb_pddaan1";
            this.rb_pddaan1.Size = new System.Drawing.Size(70, 24);
            this.rb_pddaan1.TabIndex = 0;
            this.rb_pddaan1.TabStop = true;
            this.rb_pddaan1.Text = "正确";
            this.rb_pddaan1.UseVisualStyleBackColor = true;
            this.rb_pddaan1.CheckedChanged += new System.EventHandler(this.rb_pddaan1_CheckedChanged);
            // 
            // gb_pdtimu
            // 
            this.gb_pdtimu.Controls.Add(this.txt_pdtimu);
            this.gb_pdtimu.Dock = System.Windows.Forms.DockStyle.Top;
            this.gb_pdtimu.Location = new System.Drawing.Point(3, 30);
            this.gb_pdtimu.Name = "gb_pdtimu";
            this.gb_pdtimu.Size = new System.Drawing.Size(684, 331);
            this.gb_pdtimu.TabIndex = 2;
            this.gb_pdtimu.TabStop = false;
            this.gb_pdtimu.Text = "题目：";
            // 
            // txt_pdtimu
            // 
            this.txt_pdtimu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_pdtimu.Location = new System.Drawing.Point(3, 21);
            this.txt_pdtimu.Multiline = true;
            this.txt_pdtimu.Name = "txt_pdtimu";
            this.txt_pdtimu.Size = new System.Drawing.Size(678, 307);
            this.txt_pdtimu.TabIndex = 0;
            // 
            // toolStrip4
            // 
            this.toolStrip4.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel4,
            this.toolStripLabel7,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton9});
            this.toolStrip4.Location = new System.Drawing.Point(3, 3);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(684, 27);
            this.toolStrip4.TabIndex = 0;
            this.toolStrip4.Text = "toolStrip4";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(122, 24);
            this.toolStripLabel4.Text = "toolStripLabel4";
            // 
            // toolStripLabel7
            // 
            this.toolStripLabel7.Name = "toolStripLabel7";
            this.toolStripLabel7.Size = new System.Drawing.Size(56, 24);
            this.toolStripLabel7.Text = "第 1 页";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::WindowsFormsApplication1.Properties.Resources.f060;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton4.Text = "上一页";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::WindowsFormsApplication1.Properties.Resources.right;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton5.Text = "下一页";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::WindowsFormsApplication1.Properties.Resources.btn_tijiao;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton9.Text = "保存";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.gb_tkdaan);
            this.tabPage3.Controls.Add(this.gb_tktimu);
            this.tabPage3.Controls.Add(this.toolStrip5);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(690, 602);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "填空题";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // gb_tkdaan
            // 
            this.gb_tkdaan.Controls.Add(this.txt_tkdaan);
            this.gb_tkdaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gb_tkdaan.Location = new System.Drawing.Point(3, 271);
            this.gb_tkdaan.Name = "gb_tkdaan";
            this.gb_tkdaan.Size = new System.Drawing.Size(684, 328);
            this.gb_tkdaan.TabIndex = 2;
            this.gb_tkdaan.TabStop = false;
            this.gb_tkdaan.Text = "作答区域：";
            // 
            // txt_tkdaan
            // 
            this.txt_tkdaan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_tkdaan.Location = new System.Drawing.Point(3, 21);
            this.txt_tkdaan.Multiline = true;
            this.txt_tkdaan.Name = "txt_tkdaan";
            this.txt_tkdaan.Size = new System.Drawing.Size(678, 304);
            this.txt_tkdaan.TabIndex = 0;
            this.txt_tkdaan.TextChanged += new System.EventHandler(this.txt_tkdaan_TextChanged);
            // 
            // gb_tktimu
            // 
            this.gb_tktimu.Controls.Add(this.txt_tktimu);
            this.gb_tktimu.Dock = System.Windows.Forms.DockStyle.Top;
            this.gb_tktimu.Location = new System.Drawing.Point(3, 30);
            this.gb_tktimu.Name = "gb_tktimu";
            this.gb_tktimu.Size = new System.Drawing.Size(684, 241);
            this.gb_tktimu.TabIndex = 1;
            this.gb_tktimu.TabStop = false;
            this.gb_tktimu.Text = "题目：";
            // 
            // txt_tktimu
            // 
            this.txt_tktimu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txt_tktimu.Location = new System.Drawing.Point(3, 21);
            this.txt_tktimu.Multiline = true;
            this.txt_tktimu.Name = "txt_tktimu";
            this.txt_tktimu.Size = new System.Drawing.Size(678, 217);
            this.txt_tktimu.TabIndex = 0;
            // 
            // toolStrip5
            // 
            this.toolStrip5.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip5.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel5,
            this.toolStripLabel8,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton10});
            this.toolStrip5.Location = new System.Drawing.Point(3, 3);
            this.toolStrip5.Name = "toolStrip5";
            this.toolStrip5.Size = new System.Drawing.Size(684, 27);
            this.toolStrip5.TabIndex = 0;
            this.toolStrip5.Text = "toolStrip5";
            // 
            // toolStripLabel5
            // 
            this.toolStripLabel5.Name = "toolStripLabel5";
            this.toolStripLabel5.Size = new System.Drawing.Size(122, 24);
            this.toolStripLabel5.Text = "toolStripLabel5";
            // 
            // toolStripLabel8
            // 
            this.toolStripLabel8.Name = "toolStripLabel8";
            this.toolStripLabel8.Size = new System.Drawing.Size(56, 24);
            this.toolStripLabel8.Text = "第 1 页";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::WindowsFormsApplication1.Properties.Resources.f060;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton6.Text = "上一页";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::WindowsFormsApplication1.Properties.Resources.right;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton7.Text = "下一页";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = global::WindowsFormsApplication1.Properties.Resources.btn_tijiao;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(24, 24);
            this.toolStripButton10.Text = "保存";
            this.toolStripButton10.Click += new System.EventHandler(this.toolStripButton10_Click);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip3.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsltotal,
            this.tsl_totaltime,
            this.toolStripLabel9,
            this.tsl_used,
            this.tsl_usedtime,
            this.tsl_rest,
            this.tsl_resttime,
            this.toolStripLabel10});
            this.toolStrip3.Location = new System.Drawing.Point(0, 633);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(698, 25);
            this.toolStrip3.TabIndex = 4;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // tsltotal
            // 
            this.tsltotal.Name = "tsltotal";
            this.tsltotal.Size = new System.Drawing.Size(99, 22);
            this.tsltotal.Text = "考试总时间：";
            // 
            // tsl_totaltime
            // 
            this.tsl_totaltime.Name = "tsl_totaltime";
            this.tsl_totaltime.Size = new System.Drawing.Size(21, 22);
            this.tsl_totaltime.Text = "”“";
            // 
            // toolStripLabel9
            // 
            this.toolStripLabel9.Name = "toolStripLabel9";
            this.toolStripLabel9.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel9.Text = " 分钟";
            // 
            // tsl_used
            // 
            this.tsl_used.Name = "tsl_used";
            this.tsl_used.Size = new System.Drawing.Size(69, 22);
            this.tsl_used.Text = "已用时：";
            // 
            // tsl_usedtime
            // 
            this.tsl_usedtime.Name = "tsl_usedtime";
            this.tsl_usedtime.Size = new System.Drawing.Size(21, 22);
            this.tsl_usedtime.Text = "”“";
            // 
            // tsl_rest
            // 
            this.tsl_rest.Name = "tsl_rest";
            this.tsl_rest.Size = new System.Drawing.Size(84, 22);
            this.tsl_rest.Text = "剩余时间：";
            // 
            // tsl_resttime
            // 
            this.tsl_resttime.Name = "tsl_resttime";
            this.tsl_resttime.Size = new System.Drawing.Size(21, 22);
            this.tsl_resttime.Text = "”“";
            // 
            // toolStripLabel10
            // 
            this.toolStripLabel10.Name = "toolStripLabel10";
            this.toolStripLabel10.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel10.Text = " 分钟";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmStartExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 658);
            this.Controls.Add(this.toolStrip3);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "frmStartExam";
            this.Text = "正在考试……";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmStartExam_FormClosing);
            this.Load += new System.EventHandler(this.frmStartExam_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.gb_daan.ResumeLayout(false);
            this.gb_daan.PerformLayout();
            this.gb_timu.ResumeLayout(false);
            this.gb_timu.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.gb_pddaan.ResumeLayout(false);
            this.gb_pddaan.PerformLayout();
            this.gb_pdtimu.ResumeLayout(false);
            this.gb_pdtimu.PerformLayout();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.gb_tkdaan.ResumeLayout(false);
            this.gb_tkdaan.PerformLayout();
            this.gb_tktimu.ResumeLayout(false);
            this.gb_tktimu.PerformLayout();
            this.toolStrip5.ResumeLayout(false);
            this.toolStrip5.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox gb_daan;
        private System.Windows.Forms.RadioButton rb_D;
        private System.Windows.Forms.RadioButton rb_C;
        private System.Windows.Forms.RadioButton rb_B;
        private System.Windows.Forms.RadioButton rb_A;
        private System.Windows.Forms.GroupBox gb_timu;
        private System.Windows.Forms.TextBox txt_xztimu;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.GroupBox gb_pddaan;
        private System.Windows.Forms.RadioButton rb_pddaan0;
        private System.Windows.Forms.RadioButton rb_pddaan1;
        private System.Windows.Forms.GroupBox gb_pdtimu;
        private System.Windows.Forms.TextBox txt_pdtimu;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripLabel tsltotal;
        private System.Windows.Forms.ToolStripLabel tsl_totaltime;
        private System.Windows.Forms.ToolStripLabel tsl_used;
        private System.Windows.Forms.ToolStripLabel tsl_usedtime;
        private System.Windows.Forms.ToolStripLabel tsl_rest;
        private System.Windows.Forms.ToolStripLabel tsl_resttime;
        private System.Windows.Forms.GroupBox gb_tkdaan;
        private System.Windows.Forms.TextBox txt_tkdaan;
        private System.Windows.Forms.GroupBox gb_tktimu;
        private System.Windows.Forms.TextBox txt_tktimu;
        private System.Windows.Forms.ToolStrip toolStrip5;
        private System.Windows.Forms.ToolStripLabel toolStripLabel5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripLabel toolStripLabel6;
        private System.Windows.Forms.ToolStripLabel toolStripLabel7;
        private System.Windows.Forms.ToolStripLabel toolStripLabel8;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripLabel toolStripLabel9;
        private System.Windows.Forms.ToolStripLabel toolStripLabel10;
    }
}