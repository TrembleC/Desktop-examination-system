﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmUpdatePassword : Form
    {
        public frmUpdatePassword()
        {
            InitializeComponent();
        }
        public string updateUsername = "";
        public string updateUserId = "";
        public string updatePassWord = "";
        public SqlConnection conn = BassClass.DBCon();
        private void btn_yes_Click(object sender, EventArgs e)
        {
            if (txt_old.Text.Trim() == "")
            {
                MessageBox.Show("提示：输入旧密码！", "警告");
            }
            else
            {
                if (txt_new.Text.Trim() == "")
                {
                    MessageBox.Show("提示：输入新密码！", "警告");
                }
                else
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from tb_User where UserFlag=0 and UserName='" + updateUsername + "'and UserPwd='" + txt_old.Text.Trim() + "'", conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    if (sdr.HasRows)
                    {
                        sdr.Close();
                        cmd = new SqlCommand("update tb_User set UserPwd='" + txt_new.Text.Trim() + "' where UserFlag=0 and UserName='" + updateUsername + "'", conn);
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            MessageBox.Show("提示：密码修改成功！", "提示");
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("提示：旧密码错误！", "警告");
                    }
                    conn.Close();
                }
            }
        }

        private void btn_no_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
