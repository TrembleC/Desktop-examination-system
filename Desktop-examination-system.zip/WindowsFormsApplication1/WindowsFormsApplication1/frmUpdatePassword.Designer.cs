﻿namespace WindowsFormsApplication1
{
    partial class frmUpdatePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labOld = new System.Windows.Forms.Label();
            this.labNew = new System.Windows.Forms.Label();
            this.txt_old = new System.Windows.Forms.TextBox();
            this.txt_new = new System.Windows.Forms.TextBox();
            this.btn_yes = new System.Windows.Forms.Button();
            this.btn_no = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labOld
            // 
            this.labOld.AutoSize = true;
            this.labOld.BackColor = System.Drawing.Color.Transparent;
            this.labOld.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labOld.Location = new System.Drawing.Point(40, 65);
            this.labOld.Name = "labOld";
            this.labOld.Size = new System.Drawing.Size(89, 19);
            this.labOld.TabIndex = 0;
            this.labOld.Text = "旧密码：";
            // 
            // labNew
            // 
            this.labNew.AutoSize = true;
            this.labNew.BackColor = System.Drawing.Color.Transparent;
            this.labNew.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labNew.Location = new System.Drawing.Point(40, 166);
            this.labNew.Name = "labNew";
            this.labNew.Size = new System.Drawing.Size(89, 19);
            this.labNew.TabIndex = 1;
            this.labNew.Text = "新密码：";
            // 
            // txt_old
            // 
            this.txt_old.Location = new System.Drawing.Point(135, 62);
            this.txt_old.Name = "txt_old";
            this.txt_old.Size = new System.Drawing.Size(198, 25);
            this.txt_old.TabIndex = 2;
            // 
            // txt_new
            // 
            this.txt_new.Location = new System.Drawing.Point(135, 163);
            this.txt_new.Name = "txt_new";
            this.txt_new.Size = new System.Drawing.Size(198, 25);
            this.txt_new.TabIndex = 3;
            // 
            // btn_yes
            // 
            this.btn_yes.BackColor = System.Drawing.Color.LightGray;
            this.btn_yes.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_yes.Location = new System.Drawing.Point(44, 248);
            this.btn_yes.Name = "btn_yes";
            this.btn_yes.Size = new System.Drawing.Size(102, 53);
            this.btn_yes.TabIndex = 4;
            this.btn_yes.Text = "修改";
            this.btn_yes.UseVisualStyleBackColor = false;
            this.btn_yes.Click += new System.EventHandler(this.btn_yes_Click);
            // 
            // btn_no
            // 
            this.btn_no.BackColor = System.Drawing.Color.LightGray;
            this.btn_no.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_no.Location = new System.Drawing.Point(231, 248);
            this.btn_no.Name = "btn_no";
            this.btn_no.Size = new System.Drawing.Size(102, 53);
            this.btn_no.TabIndex = 5;
            this.btn_no.Text = "取消";
            this.btn_no.UseVisualStyleBackColor = false;
            this.btn_no.Click += new System.EventHandler(this.btn_no_Click);
            // 
            // frmUpdatePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(389, 330);
            this.Controls.Add(this.btn_no);
            this.Controls.Add(this.btn_yes);
            this.Controls.Add(this.txt_new);
            this.Controls.Add(this.txt_old);
            this.Controls.Add(this.labNew);
            this.Controls.Add(this.labOld);
            this.Name = "frmUpdatePassword";
            this.Text = "修改密码";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labOld;
        private System.Windows.Forms.Label labNew;
        private System.Windows.Forms.TextBox txt_old;
        private System.Windows.Forms.TextBox txt_new;
        private System.Windows.Forms.Button btn_yes;
        private System.Windows.Forms.Button btn_no;
    }
}