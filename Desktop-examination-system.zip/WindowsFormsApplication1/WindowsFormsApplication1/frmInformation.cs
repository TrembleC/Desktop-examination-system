﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmInformation : Form
    {
        public frmInformation()
        {
            InitializeComponent();
        }
        public string updateUsername = "";
        public string updateUserId = "";
        public string updatePassWord = "";
        public string name = "";
        public string tell = "";
        public string eMail = "";
        public string birthday = "";

        public SqlConnection conn = BassClass.DBCon();

        private void button1_Click(object sender, EventArgs e)
        {

            if (txt_name.Text.Trim() == "" || txt_tell.Text.Trim() == "" || txt_eMail.Text.Trim() == "")
            {
                MessageBox.Show("提示：\n请补全信息");
            }
            else
            {
                if (!txt_eMail.Text.Trim().Contains("@") || !txt_eMail.Text.Trim().Contains(".com"))
                {
                    MessageBox.Show("邮箱格式应为：xxx@xx.com");
                }
                else
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("select * from tb_User where UserFlag=0 and UserName='" + updateUsername + "'and UserPwd='" + updatePassWord + "'", conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    if (sdr.HasRows)
                    {
                        sdr.Close();
                        cmd = new SqlCommand("update tb_User set Name='" + txt_name.Text.Trim() + "',Tell='" + txt_tell.Text.Trim() + "',eMail='" + txt_eMail.Text.Trim() + "',Birthday='" + dtp_birthday.Text.Trim() + "' where UserFlag=0 and UserName='" + updateUsername + "'", conn);
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            MessageBox.Show("提示：\n信息更新成功！");
                            this.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("提示：\n信息更新失败");
                    }
                    conn.Close();
                }
            }
        }

        private void txt_tell_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(((e.KeyChar >= '0') && (e.KeyChar <= '9')) || e.KeyChar <= 31))
            {
                if (e.KeyChar == '.')
                {
                    e.Handled = true;
                }
                else
                    e.Handled = true;
            }
            else
            {
                if (e.KeyChar <= 31)
                {
                    e.Handled = false;
                }
                else if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
                {
                    if (((TextBox)sender).Text.ToString() != "")
                    {
                        if (Convert.ToDouble(((TextBox)sender).Text) == 0)
                        {
                            if (((TextBox)sender).Text.Trim().IndexOf('.') > -1)
                            {
                                e.Handled = false;
                            }
                            else
                            {
                                e.Handled = true;
                            }
                        }
                    }
                    else
                    {
                        e.Handled = false;
                    }
                }
            }
        }

        private void frmInformation_Load(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_User where UserFlag=0 and UserName='" + updateUsername + "'and UserPwd='" + updatePassWord + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
                txt_name.Text = sdr["Name"].ToString();
                txt_tell.Text = sdr["Tell"].ToString();
                txt_eMail.Text = sdr["eMail"].ToString();
                dtp_birthday.Text = sdr["Birthday"].ToString();
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
