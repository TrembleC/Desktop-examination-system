﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmAdminAddFillExam : Form
    {
        public frmAdminAddFillExam()
        {
            InitializeComponent();
        }
        public string timu = "";
        public string daan = "";
        public int mid;

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txt_timu.Text.Trim() == "" || txt_daan.Text.Trim() == "")
            {
                MessageBox.Show("提示：请将信息填写完整！", "警告");
            }
            else if (timu != "" || daan != "")
            {
                string sql = "update tb_Test set subject='" + txt_timu.Text.Trim() + "',rightkey='" + txt_daan.Text.Trim() + "' where ID=" + mid;
                BassClass.UpdateData(sql);
                this.Close();
            }
            else
            {

                string sql = "insert into tb_Test(TypeID,subject,rightkey) values(3,'" + txt_timu.Text.Trim() + "','" + txt_daan.Text.Trim() + "')";
                BassClass.InsertData(sql);
                txt_daan.Text = "";
                txt_timu.Text = "";

            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAdminAddFillExam_Load(object sender, EventArgs e)
        {
            txt_timu.Text = timu;
            txt_daan.Text = daan;
        }
    }
}