﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace WindowsFormsApplication1
{
    public partial class frmStartExam : Form
    {
        public frmStartExam()
        {
            InitializeComponent();
        }
        public string username = "";
        public string userId = "";
        public string userPAssword = "";
        public string studentNum = "";
        SqlConnection conn = BassClass.DBCon();
        SqlCommand cmd;
        Label[] lbl = new Label[10];
        RadioButton[] rb = new RadioButton[100];
        public static ArrayList al = new ArrayList();
        public static ArrayList al1 = new ArrayList();
        public static ArrayList al2 = new ArrayList();
        int i = 0;
        int j = 0;
        int k = 0;
        public static bool[,] RbAry;
        public static bool[,] RbPdAry;
        public static string[] txttkAry;
        public static string RightAns = "";
        public static string[] StudentAns;
        public static string RightAns1 = "";
        public static string[] StudentAns1;
        public static string[] RightAns2;
        public static string[] StudentAns2;
        int examTime;
        int xzNum;
        int xzFz;
        int pdNum;
        int pdFz;
        int tkNum;
        int tkFz;
        int xzflag;
        int pdflag;
        int tkflag;

        private void frmStartExam_Load(object sender, EventArgs e)
        {
            toolStripLabel1.Text = "当前用户ID：" + userId.ToString();
            toolStripLabel2.Text = "当前用户：" + username.ToString();
            conn.Open();
            SqlCommand cd = new SqlCommand("select *  from tb_ExamSet", conn);
            SqlDataReader sr = cd.ExecuteReader();
            sr.Read();
            examTime = Convert.ToInt32(sr[7].ToString());
            xzNum = Convert.ToInt32(sr[1].ToString());
            xzFz = Convert.ToInt32(sr[2].ToString());
            pdNum = Convert.ToInt32(sr[3].ToString());
            pdFz = Convert.ToInt32(sr[4].ToString());
            tkNum = Convert.ToInt32(sr[5].ToString());
            tkFz = Convert.ToInt32(sr[6].ToString());
            sr.Close();
            conn.Close();
            tsl_totaltime.Text = examTime.ToString();
            tsl_resttime.Text = examTime.ToString();


            //初始化选择题页面
            xzflag = xzNum / xzFz;
            toolStripButton2.Enabled = false;
            conn.Open();
            string strSQL1 = "select count(*) from tb_Test where TypeID=1";
            SqlCommand cmdx = new SqlCommand(strSQL1, conn);
            int jj = Convert.ToInt32(cmdx.ExecuteScalar());
            conn.Close();
            if (xzflag > jj)
            {
                MessageBox.Show("提示：抽取试题数量大于数据库中选择题的数量，请联系管理员向数据库中添加选择题后再来答卷！", "警告");
               
            }
            else
            {
                StudentAns = new string[xzflag];
                RbAry = new bool[xzflag, 4];
                for (int ii = 0; ii < xzflag; ii++)
                    for (int j2 = 0; j2 < 4; j2++)
                    {
                        RbAry[i, j] = false;
                    }
                for (int kk = 0; kk < StudentAns.Length; kk++)
                {
                    StudentAns[kk] = "F";
                }
                if (xzNum == 0)
                {
                    toolStripLabel3.Text = "没有抽取试题！";
                    toolStripButton2.Enabled = false;
                    toolStripButton3.Enabled = false;
                }
                else
                {
                    conn.Open();
                    cmd = new SqlCommand("select top " + xzflag + " * from tb_Test where TypeID=1 order by newid()", conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        al.Add(sdr[0].ToString());
                        RightAns += sdr[3].ToString().Trim();
                    }
                    sdr.Close();
                    string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al[0]);
                    SqlCommand cmd1 = new SqlCommand(sql, conn);
                    SqlDataReader sdr1 = cmd1.ExecuteReader();
                    sdr1.Read();
                    txt_xztimu.Text = sdr1[2].ToString();
                    rb_A.Text += sdr1[4].ToString();
                    rb_B.Text += sdr1[5].ToString();
                    rb_C.Text += sdr1[6].ToString();
                    rb_D.Text += sdr1[7].ToString();
                    conn.Close();
                    toolStripLabel3.Text = "[共有" + al.Count.ToString() + "道试题]";
                }
            }


            //初始化判断题页面
            pdflag = pdNum / pdFz;
            toolStripButton4.Enabled = false;
            conn.Open();
            string strSQL2 = "select count(*) from tb_Test where TypeID=2";
            SqlCommand cmdm = new SqlCommand(strSQL2, conn);
            int dd = Convert.ToInt32(cmdm.ExecuteScalar());
            conn.Close();
            if (pdflag > dd)
            {
          
                MessageBox.Show("提示：抽取试题数量大于数据库中判断题的数量，请联系管理员向数据库中添加判断题后再来答卷！", "警告");
               
               
            }
            else
            {
                StudentAns1 = new string[pdflag];
                RbPdAry = new bool[pdflag, 2];
                for (int p = 0; p < pdflag; p++)
                    for (int d = 0; d < 2; d++)
                    {
                        RbPdAry[p, d] = false;
                    }
                for (int mm = 0; mm < StudentAns1.Length; mm++)
                {
                    StudentAns1[mm] = "F";
                }
                if (pdNum == 0)
                {
                    toolStripLabel4.Text = "没有抽取试题！";
                    toolStripButton4.Enabled = false;
                    toolStripButton5.Enabled = false;
                }
                else
                {
                    conn.Open();
                    SqlCommand cmd2 = new SqlCommand("select top " + pdflag + " * from tb_Test where TypeID=2 order by newid()", conn);
                    SqlDataReader sdr2 = cmd2.ExecuteReader();
                    while (sdr2.Read())
                    {
                        al1.Add(sdr2[0].ToString());
                        RightAns1 += sdr2[3].ToString().Trim();
                    }
                    sdr2.Close();
                    string sql1 = "select * from tb_Test where ID=" + Convert.ToInt32(al1[0]);
                    SqlCommand cmd3 = new SqlCommand(sql1, conn);
                    SqlDataReader sdr3 = cmd3.ExecuteReader();
                    sdr3.Read();
                    txt_pdtimu.Text = sdr3[2].ToString();
                    conn.Close();
                    toolStripLabel4.Text = "[共有" + al1.Count.ToString() + "道试题]";
                }
            }

            //初始化填空题页面
            tkflag = tkNum / tkFz;
            toolStripButton6.Enabled = false;
            conn.Open();
            string strSQL3 = "select count(*) from tb_Test where TypeID=3";
            SqlCommand cmdpp = new SqlCommand(strSQL3, conn);
            int pp = Convert.ToInt32(cmdpp.ExecuteScalar());
            conn.Close();
            if (tkflag > pp)
            {
               
                MessageBox.Show("提示：抽取试题数量大于数据库中填空题的数量，请联系管理员向数据库中添加填空题后再来答卷！", "警告");
               
            }
            else
            {
                StudentAns2 = new string[tkflag];
                RightAns2 = new string[tkflag];
                txttkAry = new string[tkflag];
                for (int l = 0; l < txttkAry.Length; l++)
                {
                    txttkAry[l] = "";
                }
                for (int nn = 0; nn < StudentAns2.Length; nn++)
                {
                    StudentAns2[nn] = "F";
                }
                if (tkNum == 0)
                {
                    toolStripLabel5.Text = "没有抽取试题！";
                    toolStripButton6.Enabled = false;
                    toolStripButton7.Enabled = false;
                }
                else
                {
                    conn.Open();
                    SqlCommand cmd4 = new SqlCommand("select top " + tkflag + " * from tb_Test where TypeID=3 order by newid()", conn);
                    SqlDataReader sdr4 = cmd4.ExecuteReader();
                    int uu = 0;
                    while (sdr4.Read())
                    {
                        al2.Add(sdr4[0].ToString());
                        RightAns2[uu] = sdr4[3].ToString().Trim();
                        uu++;
                    }
                    sdr4.Close();
                    string sql2 = "select * from tb_Test where ID=" + Convert.ToInt32(al2[0]);
                    SqlCommand cmd5 = new SqlCommand(sql2, conn);
                    SqlDataReader sdr5 = cmd5.ExecuteReader();
                    sdr5.Read();
                    txt_tktimu.Text = sdr5[2].ToString();
                    conn.Close();
                    toolStripLabel5.Text = "[共有" + al2.Count.ToString() + "道试题]";
                }
            }
            if (xzflag > jj || pdflag > dd || tkflag > pp)
            {
                this.Dispose();
                frmStudentExam stuexam = new frmStudentExam();
                stuexam.Username = username;
                stuexam.UserId = userId;
                stuexam.Userpwd = userPAssword;
                stuexam.Show();
            }
        }

        //选择题下一页
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            i++;
            rb_A.Checked = RbAry[i, 0];
            rb_B.Checked = RbAry[i, 1];
            rb_C.Checked = RbAry[i, 2];
            rb_D.Checked = RbAry[i, 3];
            rb_A.Text = "A- ";
            rb_B.Text = "B- ";
            rb_C.Text = "C- ";
            rb_D.Text = "D- ";


            if (i == xzflag - 1)
                toolStripButton3.Enabled = false;
            if (i <= al.Count - 1)
            {
                toolStripButton2.Enabled = true;
                toolStripLabel6.Text = "第 " + Convert.ToString(i + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al[i]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                txt_xztimu.Text = sdr1[2].ToString();
                rb_A.Text += sdr1[4].ToString();
                rb_B.Text += sdr1[5].ToString();
                rb_C.Text += sdr1[6].ToString();
                rb_D.Text += sdr1[7].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton3.Enabled = false;
            }
        }

        //选择题上一页
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            i--;
            rb_A.Checked = RbAry[i, 0];
            rb_B.Checked = RbAry[i, 1];
            rb_C.Checked = RbAry[i, 2];
            rb_D.Checked = RbAry[i, 3];
            rb_A.Text = "A- ";
            rb_B.Text = "B- ";
            rb_C.Text = "C- ";
            rb_D.Text = "D- ";
            if (i == 0)
                toolStripButton2.Enabled = false;
            if (i >= 0)
            {
                toolStripButton3.Enabled = true;
                toolStripLabel6.Text = "第 " + Convert.ToString(i + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al[i]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                txt_xztimu.Text = sdr1[2].ToString();
                rb_A.Text += sdr1[4].ToString();
                rb_B.Text += sdr1[5].ToString();
                rb_C.Text += sdr1[6].ToString();
                rb_D.Text += sdr1[7].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton2.Enabled = false;
                toolStripButton3.Enabled = true;
            }
        }

        //判断题上一页
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            j--;
            rb_pddaan1.Checked = RbPdAry[j, 0];
            rb_pddaan0.Checked = RbPdAry[j, 1];
            if (j == 0)
                toolStripButton4.Enabled = false;
            if (j >= 0)
            {
                toolStripButton5.Enabled = true;
                toolStripLabel7.Text = "第 " + Convert.ToString(j + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al1[j]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                this.txt_pdtimu.Text = sdr1[2].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton4.Enabled = false;
                toolStripButton5.Enabled = true;
            }
        }

        //判断题下一页
        private void toolStripButton5_Click(object sender, EventArgs e)
        {

            j++;
            rb_pddaan1.Checked = RbPdAry[j, 0];
            rb_pddaan0.Checked = RbPdAry[j, 1];
            if (j == pdflag - 1)
                toolStripButton5.Enabled = false;//下一页按钮
            if (j <= al1.Count - 1)
            {
                toolStripButton4.Enabled = true;//上一页按钮
                toolStripLabel7.Text = "第 " + Convert.ToString(j + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al1[j]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                txt_pdtimu.Text = sdr1[2].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton5.Enabled = false;
            }
        }

        //填空题下一页
        private void toolStripButton7_Click(object sender, EventArgs e)
        {

            k++;
            txt_tkdaan.Text = txttkAry[k];
            if (k == tkflag - 1)
                toolStripButton7.Enabled = false;//下一页按钮
            if (k <= al2.Count - 1)
            {
                toolStripButton6.Enabled = true;//上一页按钮
                toolStripLabel8.Text = "第 " + Convert.ToString(k + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al2[k]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                txt_tktimu.Text = sdr1[2].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton7.Enabled = false;
            }
        }

        //填空题上一页
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            k--;
            txt_tkdaan.Text = txttkAry[k];
            if (k == 0)
                toolStripButton6.Enabled = false;
            if (k >= 0)
            {
                toolStripButton7.Enabled = true;
                toolStripLabel8.Text = "第 " + Convert.ToString(k + 1) + " 页";
                conn.Open();
                string sql = "select * from tb_Test where ID=" + Convert.ToInt32(al2[k]);
                SqlCommand cmd1 = new SqlCommand(sql, conn);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                txt_tktimu.Text = sdr1[2].ToString();
                sdr1.Close();
                conn.Close();
            }
            else
            {
                toolStripButton6.Enabled = false;
                toolStripButton7.Enabled = true;
            }
        }

        //实现时间计时的函数
        public int flag = 1;
        public int nowTime = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            tsl_usedtime.Text = "已用时" + nowTime.ToString() + "分 " + flag.ToString() + "秒";
            if (flag % 60 == 0)
            {
                nowTime++;

                tsl_resttime.Text = Convert.ToString(Convert.ToInt32(tsl_totaltime.Text.Trim()) - Convert.ToInt32(nowTime));
                flag = 0;

            }
            if (tsl_resttime.Text.Trim() == "0")
            {
                timer1.Stop();
                toolStripButton1_Click(sender, e);
            }
            flag++;
        }

        //提交按钮事件
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            int bb = 1;
            string sql = "update tb_User set IsTest=1 where UserName='" + username + "'";
            SqlConnection conn = BassClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            if (tsl_resttime.Text.Trim() == "0")
            {

                timer1.Stop();
                toolStripButton8_Click(sender, e);
                toolStripButton9_Click(sender, e);
                toolStripButton10_Click(sender, e);
                MessageBox.Show("提示:\n时间已到，已自动提交试卷！");
            }
            else
            {
                if (MessageBox.Show("提示：您真的要提交考卷吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
                {
                    timer1.Stop();
                    toolStripButton8_Click(sender, e);
                    toolStripButton9_Click(sender, e);
                    toolStripButton10_Click(sender, e);
                }
                else
                {
                    bb = 2;
                }
            }
            if (bb == 1)
            {
                int allscore = StuScore1 + StuScore2 + StuScore;
                string sql1 = "update tb_ExamResult set exampoint='" + allscore + "' where UserID='" + userId + "'";
                cmd = new SqlCommand(sql1, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                this.OnClosed(e);
                this.Hide();
                frmStudentExam stuexam = new frmStudentExam();
                stuexam.Username = username;
                stuexam.UserId = userId;
                stuexam.Userpwd = userPAssword;
                stuexam.Show();
            }
        }

        //选择题分数计算
        public string stuAns = "";
        public int StuScore = 0;
        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            for (int aa = 0; aa < StudentAns.Length; aa++)
            {
                stuAns += StudentAns[aa].ToString();
            }

            for (int i = 0; i < xzflag; i++)
            {
                if (RightAns.Substring(i, 1).Equals(this.stuAns.Substring(i, 1)))
                {
                    StuScore += xzFz;
                }
            }
            string sql1 = "select * from tb_ExamResult where UserID='" + userId + "'";
            SqlConnection conn = BassClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql1, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                sdr.Close();
                cmd = new SqlCommand("update tb_ExamResult set selectexam='" + StuScore + "' where UserID='" + userId + "'", conn);
                cmd.ExecuteNonQuery();
            }
            else
            {
                sdr.Close();
                cmd = new SqlCommand("insert into tb_ExamResult(UserID,selectexam) values('" + userId + "','" + StuScore + "')", conn);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
            //MessageBox.Show("选择题保存成功！");
        }

        //选择题答案
        private void rb_A_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_A.Checked == true)
            {
                StudentAns[i] = "A";
                RbAry[i, 0] = true; ;
            }
        }

        private void rb_B_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_B.Checked == true)
            {
                StudentAns[i] = "B";
                RbAry[i, 1] = true; ;
            }
        }

        private void rb_C_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_C.Checked == true)
            {
                StudentAns[i] = "C";
                RbAry[i, 2] = true; ;
            }
        }

        private void rb_D_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_D.Checked == true)
            {
                StudentAns[i] = "D";
                RbAry[i, 3] = true; ;
            }
        }

        //判断题分数计算
        public string pdstuAns = "";
        public int StuScore1 = 0;

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            for (int aa = 0; aa < StudentAns1.Length; aa++)
            {
                pdstuAns += StudentAns1[aa].ToString();
            }

            for (int i = 0; i < pdflag; i++)
            {
                if (RightAns1.Substring(i, 1).Equals(pdstuAns.Substring(i, 1)))
                {
                    StuScore1 += pdFz;
                }
            }
            string sql1 = "select * from tb_ExamResult where UserID='" + userId + "'";
            SqlConnection conn = BassClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql1, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                sdr.Close();
                cmd = new SqlCommand("update tb_ExamResult set judgeexam='" + StuScore1 + "' where UserID='" + userId + "'", conn);
                cmd.ExecuteNonQuery();
            }
            else
            {
                sdr.Close();
                cmd = new SqlCommand("insert into tb_ExamResult(UserID,judgeexam) values('" + userId + "','" + StuScore1 + "')", conn);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
            //MessageBox.Show("判断题保存成功！");
        }

        //判断题答案
        private void rb_pddaan1_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_pddaan1.Checked == true)
            {
                StudentAns1[j] = "1";
                RbPdAry[j, 0] = true;
            }
        }

        private void rb_pddaan0_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_pddaan0.Checked == true)
            {
                StudentAns1[j] = "0";
                RbPdAry[j, 1] = true;
            }
        }

        //填空题分数计算
        public int StuScore2 = 0;
        private void toolStripButton10_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < tkflag; i++)
            {
                if (RightAns2[i] == StudentAns2[i])
                {
                    StuScore2 += tkFz;
                }
            }
            string sql1 = "select * from tb_ExamResult where UserID='" + userId + "'";
            SqlConnection conn = BassClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql1, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                sdr.Close();
                cmd = new SqlCommand("update tb_ExamResult set Fileexam='" + StuScore2 + "' where UserID='" + userId + "'", conn);
                cmd.ExecuteNonQuery();
            }
            else
            {
                sdr.Close();
                cmd = new SqlCommand("insert into tb_ExamResult(UserID,Fileexam) values('" + userId + "','" + StuScore2 + "')", conn);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
            //MessageBox.Show("填空题保存成功！");
        }

        //填空题答案
        private void txt_tkdaan_TextChanged(object sender, EventArgs e)
        {
            StudentAns2[k] = txt_tkdaan.Text;
            txttkAry[k] = txt_tkdaan.Text;
        }

        private void frmStartExam_FormClosing(object sender, FormClosingEventArgs e)
        {
            int bb = 1;
            string sql = "update tb_User set IsTest=1 where UserName='" + username + "'";
            SqlConnection conn = BassClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            if (MessageBox.Show("提示：您真的要提交考卷吗？", "提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                timer1.Stop();
                toolStripButton8_Click(sender, e);
                toolStripButton9_Click(sender, e);
                toolStripButton10_Click(sender, e);
                e.Cancel = false;//关闭
            }
            else
            {
                bb = 2;
                e.Cancel = true;//不关闭了
            }
            
            if (bb == 1)
            {
                int allscore = StuScore1 + StuScore2 + StuScore;
                string sql1 = "update tb_ExamResult set exampoint='" + allscore + "' where UserID='" + userId + "'";
                cmd = new SqlCommand(sql1, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                frmStudentExam stuexam = new frmStudentExam();
                stuexam.Username = username;
                stuexam.UserId = userId;
                stuexam.Userpwd = userPAssword;
                stuexam.Show();     
            }
        }
    }
}

