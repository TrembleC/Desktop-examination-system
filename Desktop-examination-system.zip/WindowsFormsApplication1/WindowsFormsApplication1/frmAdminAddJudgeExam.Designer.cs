﻿namespace WindowsFormsApplication1
{
    partial class frmAdminAddJudgeExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labtimu = new System.Windows.Forms.Label();
            this.labdaan = new System.Windows.Forms.Label();
            this.txttimu = new System.Windows.Forms.TextBox();
            this.cbb_daan = new System.Windows.Forms.ComboBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labtimu
            // 
            this.labtimu.AutoSize = true;
            this.labtimu.BackColor = System.Drawing.Color.Transparent;
            this.labtimu.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labtimu.Location = new System.Drawing.Point(36, 54);
            this.labtimu.Name = "labtimu";
            this.labtimu.Size = new System.Drawing.Size(129, 19);
            this.labtimu.TabIndex = 0;
            this.labtimu.Text = "判断题题目：";
            // 
            // labdaan
            // 
            this.labdaan.AutoSize = true;
            this.labdaan.BackColor = System.Drawing.Color.Transparent;
            this.labdaan.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labdaan.Location = new System.Drawing.Point(36, 211);
            this.labdaan.Name = "labdaan";
            this.labdaan.Size = new System.Drawing.Size(129, 19);
            this.labdaan.TabIndex = 1;
            this.labdaan.Text = "判断题答案：";
            // 
            // txttimu
            // 
            this.txttimu.Location = new System.Drawing.Point(171, 54);
            this.txttimu.Multiline = true;
            this.txttimu.Name = "txttimu";
            this.txttimu.Size = new System.Drawing.Size(436, 121);
            this.txttimu.TabIndex = 2;
            // 
            // cbb_daan
            // 
            this.cbb_daan.FormattingEnabled = true;
            this.cbb_daan.Items.AddRange(new object[] {
            "请选择答案",
            "正确",
            "错误"});
            this.cbb_daan.Location = new System.Drawing.Point(171, 209);
            this.cbb_daan.Name = "cbb_daan";
            this.cbb_daan.Size = new System.Drawing.Size(121, 23);
            this.cbb_daan.TabIndex = 3;
            this.cbb_daan.Text = "请选择答案";
            this.cbb_daan.SelectedIndexChanged += new System.EventHandler(this.cbb_daan_SelectedIndexChanged);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.LightGray;
            this.btn_save.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_save.Location = new System.Drawing.Point(40, 252);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(152, 54);
            this.btn_save.TabIndex = 4;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.LightGray;
            this.btn_cancel.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_cancel.Location = new System.Drawing.Point(455, 252);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(152, 54);
            this.btn_cancel.TabIndex = 5;
            this.btn_cancel.Text = "取消";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // frmAdminAddJudgeExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(629, 346);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.cbb_daan);
            this.Controls.Add(this.txttimu);
            this.Controls.Add(this.labdaan);
            this.Controls.Add(this.labtimu);
            this.Name = "frmAdminAddJudgeExam";
            this.Text = "考试管理-添加判断题";
            this.Load += new System.EventHandler(this.frmAdminAddJudgeExam_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labtimu;
        private System.Windows.Forms.Label labdaan;
        private System.Windows.Forms.TextBox txttimu;
        private System.Windows.Forms.ComboBox cbb_daan;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_cancel;
    }
}