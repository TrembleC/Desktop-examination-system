﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmAdminFindScore : Form
    {
        public frmAdminFindScore()
        {
            InitializeComponent();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (cbbSC.Text.Trim() == "请选择查询条件")
            {
                if (MessageBox.Show("是否进行模糊查询？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    string sql = "";
                    sql = "select ID as '系统编号',UserID as '用户ID',selectexam as '选择题',judgeexam as '判断题',Fileexam as '填空题',exampoint as '考试总分' from tb_ExamResult";
                    BassClass.DataGridViewBind(dataGridView1, sql);
                }
                else
                {
                    MessageBox.Show("请选择查询条件！");
                }
            }
            else
            {
                if (cbbSC.Text.Trim() == "用户ID")
                {
                    string sql = "";
                    if (txtKey.Text.Trim() == "")
                    {
                        sql = "select ID as '系统编号',UserID as '用户ID',selectexam as '选择题',judgeexam as '判断题',Fileexam as '填空题',exampoint as '考试总分' from tb_ExamResult";
                        BassClass.DataGridViewBind(dataGridView1, sql);
                    }
                    else
                    {
                        sql = "select ID as '系统编号',UserID as '用户ID',selectexam as '选择题',judgeexam as '判断题',Fileexam as '填空题',exampoint as '考试总分' from tb_ExamResult where UserID like '%" + txtKey.Text.Trim() + "%'";
                        BassClass.DataGridViewBind(dataGridView1, sql);
                    }
                }
                else
                {
                    string sql = "";
                    if (txtKey.Text.Trim() == "")
                    {
                        sql = "select ID as '系统编号',UserID as '用户ID',selectexam as '选择题',judgeexam as '判断题  ',Fileexam as '填空题',exampoint as '考试总分' from tb_ExamResult";
                        BassClass.DataGridViewBind(dataGridView1, sql);
                    }
                    else
                    {
                        sql = "select ID as '系统编号',UserID as '用户ID',selectexam as '选择题',judgeexam as '判断题',Fileexam as '填空题',exampoint as '考试总分' from tb_ExamResult where UserID in (select UserID from tb_User where UserName like '%" + txtKey.Text.Trim() + "%')";
                        SqlConnection conn = BassClass.DBCon();
                        conn.Open();
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        SqlDataReader sdr = cmd.ExecuteReader();
                        BassClass.DataGridViewBind(dataGridView1, sql);
                    }
                }
            }
        }
    }
}
