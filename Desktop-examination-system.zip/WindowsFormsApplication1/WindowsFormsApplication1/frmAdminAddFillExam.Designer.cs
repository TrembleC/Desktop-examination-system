﻿namespace WindowsFormsApplication1
{
    partial class frmAdminAddFillExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_timu = new System.Windows.Forms.Label();
            this.lab_daan = new System.Windows.Forms.Label();
            this.txt_timu = new System.Windows.Forms.TextBox();
            this.txt_daan = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lab_timu
            // 
            this.lab_timu.AutoSize = true;
            this.lab_timu.BackColor = System.Drawing.Color.Transparent;
            this.lab_timu.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_timu.Location = new System.Drawing.Point(66, 56);
            this.lab_timu.Name = "lab_timu";
            this.lab_timu.Size = new System.Drawing.Size(109, 19);
            this.lab_timu.TabIndex = 0;
            this.lab_timu.Text = "题目名称：";
            // 
            // lab_daan
            // 
            this.lab_daan.AutoSize = true;
            this.lab_daan.BackColor = System.Drawing.Color.Transparent;
            this.lab_daan.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_daan.Location = new System.Drawing.Point(66, 248);
            this.lab_daan.Name = "lab_daan";
            this.lab_daan.Size = new System.Drawing.Size(109, 19);
            this.lab_daan.TabIndex = 1;
            this.lab_daan.Text = "题目答案：";
            // 
            // txt_timu
            // 
            this.txt_timu.BackColor = System.Drawing.SystemColors.Window;
            this.txt_timu.Location = new System.Drawing.Point(181, 56);
            this.txt_timu.Multiline = true;
            this.txt_timu.Name = "txt_timu";
            this.txt_timu.Size = new System.Drawing.Size(498, 161);
            this.txt_timu.TabIndex = 2;
            // 
            // txt_daan
            // 
            this.txt_daan.Location = new System.Drawing.Point(181, 247);
            this.txt_daan.Multiline = true;
            this.txt_daan.Name = "txt_daan";
            this.txt_daan.Size = new System.Drawing.Size(498, 161);
            this.txt_daan.TabIndex = 3;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.LightGray;
            this.btn_save.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_save.Location = new System.Drawing.Point(181, 436);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(131, 59);
            this.btn_save.TabIndex = 4;
            this.btn_save.Text = "保存";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.BackColor = System.Drawing.Color.LightGray;
            this.btn_cancel.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_cancel.Location = new System.Drawing.Point(548, 436);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(131, 59);
            this.btn_cancel.TabIndex = 5;
            this.btn_cancel.Text = "取消";
            this.btn_cancel.UseVisualStyleBackColor = false;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // frmAdminAddFillExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(723, 510);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.txt_daan);
            this.Controls.Add(this.txt_timu);
            this.Controls.Add(this.lab_daan);
            this.Controls.Add(this.lab_timu);
            this.Name = "frmAdminAddFillExam";
            this.Text = "考试管理-添加填空题";
            this.Load += new System.EventHandler(this.frmAdminAddFillExam_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_timu;
        private System.Windows.Forms.Label lab_daan;
        private System.Windows.Forms.TextBox txt_timu;
        private System.Windows.Forms.TextBox txt_daan;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_cancel;
    }
}