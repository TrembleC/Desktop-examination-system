﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApplication1
{
    class BassClass
    {
        //封装数据库连接方法
        public static SqlConnection DBCon()
        {
            return new SqlConnection("Server=.;user=sa;pwd=sa;database=ExamSystem");
        }

        //信息插入方法
        public static void InsertData(string SQLstr){
            SqlConnection conn = DBCon();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(SQLstr, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("添加成功！");
                }
                else
                {
                    MessageBox.Show("添加失败！");
                }
            }
            catch(Exception ex) {
                Console.WriteLine(ex.Message.ToString());
            }
            finally{
                conn.Close();
            }
        }

        //信息更新方法
        public static void UpdateData(string SQLstr) {
            SqlConnection conn = DBCon();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(SQLstr, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("更新成功！");
                }
                else
                {
                    MessageBox.Show("更新失败！");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        //信息删除方法
        public static void DeleteData(string SQLstr)
        {
            SqlConnection conn = DBCon();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(SQLstr, conn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("删除成功！");
                }
                else
                {
                    MessageBox.Show("删除失败！");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        //绑定DataGridView控件的方法
        public static void DataGridViewBind(DataGridView dgv, string SQLstr)
        {
            SqlConnection conn = DBCon();
            SqlDataAdapter sda = new SqlDataAdapter(SQLstr, conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dgv.DataSource = ds.Tables[0];
            int width = dgv.Width;
            int avgWidth = width / ds.Tables[0].Columns.Count;//求出每一列的header宽度
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                dgv.Columns[i].Width = avgWidth;//设置每一列的宽度
            }
        }
    }
}
