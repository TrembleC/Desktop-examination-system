﻿namespace WindowsFormsApplication1
{
    partial class frmUpdateUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_updateUser = new System.Windows.Forms.Button();
            this.cbb_isTest = new System.Windows.Forms.ComboBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.cbbusertype = new System.Windows.Forms.ComboBox();
            this.IsTest = new System.Windows.Forms.Label();
            this.pwd = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.lx = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.btn_updateUser);
            this.groupBox1.Controls.Add(this.cbb_isTest);
            this.groupBox1.Controls.Add(this.txtpassword);
            this.groupBox1.Controls.Add(this.txtuser);
            this.groupBox1.Controls.Add(this.txtuserid);
            this.groupBox1.Controls.Add(this.cbbusertype);
            this.groupBox1.Controls.Add(this.IsTest);
            this.groupBox1.Controls.Add(this.pwd);
            this.groupBox1.Controls.Add(this.username);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Controls.Add(this.lx);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 542);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "修改用户信息";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(238, 444);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 58);
            this.button2.TabIndex = 21;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_updateUser
            // 
            this.btn_updateUser.BackColor = System.Drawing.Color.LightGray;
            this.btn_updateUser.Location = new System.Drawing.Point(93, 444);
            this.btn_updateUser.Name = "btn_updateUser";
            this.btn_updateUser.Size = new System.Drawing.Size(126, 58);
            this.btn_updateUser.TabIndex = 20;
            this.btn_updateUser.Text = "确定修改";
            this.btn_updateUser.UseVisualStyleBackColor = false;
            this.btn_updateUser.Click += new System.EventHandler(this.btn_updateUser_Click);
            // 
            // cbb_isTest
            // 
            this.cbb_isTest.FormattingEnabled = true;
            this.cbb_isTest.Items.AddRange(new object[] {
            "没有参加考试",
            "已参加考试"});
            this.cbb_isTest.Location = new System.Drawing.Point(210, 364);
            this.cbb_isTest.Name = "cbb_isTest";
            this.cbb_isTest.Size = new System.Drawing.Size(154, 26);
            this.cbb_isTest.TabIndex = 19;
            this.cbb_isTest.Text = "没有参加考试";
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(153, 291);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(211, 27);
            this.txtpassword.TabIndex = 18;
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(153, 218);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(211, 27);
            this.txtuser.TabIndex = 17;
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(171, 145);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(193, 27);
            this.txtuserid.TabIndex = 16;
            // 
            // cbbusertype
            // 
            this.cbbusertype.FormattingEnabled = true;
            this.cbbusertype.Items.AddRange(new object[] {
            "学生",
            "教师"});
            this.cbbusertype.Location = new System.Drawing.Point(153, 74);
            this.cbbusertype.Name = "cbbusertype";
            this.cbbusertype.Size = new System.Drawing.Size(211, 26);
            this.cbbusertype.TabIndex = 15;
            this.cbbusertype.Text = "学生";
            this.cbbusertype.SelectedIndexChanged += new System.EventHandler(this.cbbusertype_SelectedIndexChanged);
            // 
            // IsTest
            // 
            this.IsTest.AutoSize = true;
            this.IsTest.Location = new System.Drawing.Point(89, 370);
            this.IsTest.Name = "IsTest";
            this.IsTest.Size = new System.Drawing.Size(129, 19);
            this.IsTest.TabIndex = 14;
            this.IsTest.Text = "是否已考试：";
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.Location = new System.Drawing.Point(89, 296);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(69, 19);
            this.pwd.TabIndex = 13;
            this.pwd.Text = "密码：";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Location = new System.Drawing.Point(89, 222);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(69, 19);
            this.username.TabIndex = 12;
            this.username.Text = "账号：";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(89, 148);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(89, 19);
            this.name.TabIndex = 11;
            this.name.Text = "用户ID：";
            // 
            // lx
            // 
            this.lx.AutoSize = true;
            this.lx.Location = new System.Drawing.Point(89, 74);
            this.lx.Name = "lx";
            this.lx.Size = new System.Drawing.Size(69, 19);
            this.lx.TabIndex = 10;
            this.lx.Text = "类型：";
            // 
            // frmUpdateUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(451, 542);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmUpdateUser";
            this.Text = "修改用户";
            this.Load += new System.EventHandler(this.frmUpdateUser_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbb_isTest;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.ComboBox cbbusertype;
        private System.Windows.Forms.Label IsTest;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label lx;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_updateUser;
    }
}