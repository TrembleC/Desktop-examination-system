﻿namespace WindowsFormsApplication1
{
    partial class frmStudentExam
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.学生考试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.开始考试ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统OToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改密码PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询分数ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.注销ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.个人信息ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.学生考试ToolStripMenuItem,
            this.信息管理ToolStripMenuItem,
            this.帮助HToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1025, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 学生考试ToolStripMenuItem
            // 
            this.学生考试ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.开始考试ToolStripMenuItem,
            this.退出系统OToolStripMenuItem});
            this.学生考试ToolStripMenuItem.Name = "学生考试ToolStripMenuItem";
            this.学生考试ToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.学生考试ToolStripMenuItem.Text = "学生考试(&S)";
            // 
            // 开始考试ToolStripMenuItem
            // 
            this.开始考试ToolStripMenuItem.Name = "开始考试ToolStripMenuItem";
            this.开始考试ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B)));
            this.开始考试ToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.开始考试ToolStripMenuItem.Text = "开始考试(&B)";
            this.开始考试ToolStripMenuItem.Click += new System.EventHandler(this.开始考试ToolStripMenuItem_Click);
            // 
            // 退出系统OToolStripMenuItem
            // 
            this.退出系统OToolStripMenuItem.Name = "退出系统OToolStripMenuItem";
            this.退出系统OToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.退出系统OToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.退出系统OToolStripMenuItem.Text = "退出系统(&O)";
            this.退出系统OToolStripMenuItem.Click += new System.EventHandler(this.退出系统OToolStripMenuItem_Click);
            // 
            // 信息管理ToolStripMenuItem
            // 
            this.信息管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改密码PToolStripMenuItem,
            this.查询分数ToolStripMenuItem,
            this.个人信息ToolStripMenuItem1,
            this.注销ToolStripMenuItem});
            this.信息管理ToolStripMenuItem.Name = "信息管理ToolStripMenuItem";
            this.信息管理ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.信息管理ToolStripMenuItem.Text = "信息管理(&X)";
            // 
            // 修改密码PToolStripMenuItem
            // 
            this.修改密码PToolStripMenuItem.Name = "修改密码PToolStripMenuItem";
            this.修改密码PToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.修改密码PToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.修改密码PToolStripMenuItem.Text = "修改密码(&P)";
            this.修改密码PToolStripMenuItem.Click += new System.EventHandler(this.修改密码PToolStripMenuItem_Click);
            // 
            // 查询分数ToolStripMenuItem
            // 
            this.查询分数ToolStripMenuItem.Name = "查询分数ToolStripMenuItem";
            this.查询分数ToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.查询分数ToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.查询分数ToolStripMenuItem.Text = "查询分数(&S)";
            this.查询分数ToolStripMenuItem.Click += new System.EventHandler(this.查询分数ToolStripMenuItem_Click);
            // 
            // 注销ToolStripMenuItem
            // 
            this.注销ToolStripMenuItem.Name = "注销ToolStripMenuItem";
            this.注销ToolStripMenuItem.Size = new System.Drawing.Size(218, 26);
            this.注销ToolStripMenuItem.Text = "注销";
            this.注销ToolStripMenuItem.Click += new System.EventHandler(this.注销ToolStripMenuItem_Click);
            // 
            // 个人信息ToolStripMenuItem1
            // 
            this.个人信息ToolStripMenuItem1.Name = "个人信息ToolStripMenuItem1";
            this.个人信息ToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.个人信息ToolStripMenuItem1.Size = new System.Drawing.Size(218, 26);
            this.个人信息ToolStripMenuItem1.Text = "个人信息(&I)";
            this.个人信息ToolStripMenuItem1.Click += new System.EventHandler(this.个人信息ToolStripMenuItem1_Click);
            // 
            // 帮助HToolStripMenuItem
            // 
            this.帮助HToolStripMenuItem.Name = "帮助HToolStripMenuItem";
            this.帮助HToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.帮助HToolStripMenuItem.Text = "帮助(&H)";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 569);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1025, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(167, 20);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
            // 
            // frmStudentExam
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.main;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1025, 594);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmStudentExam";
            this.Text = "学生考试主页面";
            this.Load += new System.EventHandler(this.frmStudentExam_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 学生考试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 开始考试ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统OToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改密码PToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询分数ToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem 注销ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 个人信息ToolStripMenuItem1;
    }
}