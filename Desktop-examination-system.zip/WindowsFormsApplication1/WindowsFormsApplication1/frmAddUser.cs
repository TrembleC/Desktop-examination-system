﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmAddUser : Form
    {
        public frmAddUser()
        {
            InitializeComponent();
        }

        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            if (txtuser.Text.Trim() == "" || txtpassword.Text.Trim() == "" ||
          txtuserid.Text.Trim() == "")
            {
                MessageBox.Show("提示：请将信息填写完整！");
            }
            else
            {
                int flag1;
                int flag2;
                if (cbbusertype.Text.Trim() == "学生")
                    flag1 = 0;
                else
                    flag1 = 1;
                if (cbb_isTest.Text.Trim() == "没有参加考试")
                    flag2 = 0;
                else
                    flag2 = 1;
                string sql = "insert into tb_User(UserFlag,UserID,UserName,UserPwd,IsTest)   values('" + flag1 + "','" + txtuserid.Text.Trim() + "','" + txtuser.Text.Trim() + "','" + txtpassword.Text.Trim() + "','" + flag2 + "')";
                string sql2 = "insert tb_ExamResult(UserID)values('" + txtuserid.Text.Trim() + "')";
                SqlConnection conn = BassClass.DBCon();
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql2, conn);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                }
                finally
                {
                    conn.Close();
                }
                BassClass.InsertData(sql);
                txtuser.Text = "";
                txtpassword.Text = "";
                txtuserid.Text = "";
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
