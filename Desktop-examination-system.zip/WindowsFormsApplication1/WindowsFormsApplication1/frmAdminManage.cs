﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmAdminManage : Form
    {
        public frmAdminManage()
        {
            InitializeComponent();
        }
        public string Username = "";
        public string Userpwd = "";
        public int rowIndex;
        public int rowIndex2;
        public int rowIndex3;

        private void 考试设置ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminExamSet adminexamset = new frmAdminExamSet();
            adminexamset.Show();
        }

        private void 添加选择题ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminAddSelectExam selectexam = new frmAdminAddSelectExam();
            selectexam.Show();
        }

        private void frmAdminManage_Activated(object sender, EventArgs e)
        {
            tsslAdmin.Text = "当前登录用户：" + Username + "  用户身份：管理员";
            //检索所有的选择题
            string sql = "select ID as '系统编号',subject as '选择题题目',A as '选项A',B as '选项B',C as '选项C',D as '选项D',rightkey as '正确选项' from tb_Test where TypeID=1";
            BassClass.DataGridViewBind(dataGridView1, sql);

            //检索所有的判断题
            string sql1 = "select ID as '系统编号',subject as '判断题题目',rightkey as '正确判断' from tb_Test where TypeID=2";
            BassClass.DataGridViewBind(dataGridView2, sql1);
            //检索所有的填空题
            string sql2 = "select ID as '系统编号',subject as '填空题题目',rightkey as '正确答案' from tb_Test where TypeID=3";
            BassClass.DataGridViewBind(dataGridView3, sql2);
        }

        private void 删除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //    //if (dataGridView1.SelectedRows.Count == 0)
            //    //{
            //    //    contextMenuStrip1.Enabled = false;
            //    //}
            //    //else
            //    //{
            //    //    int MMid = Convert.ToInt32(dataGridView1.SelectedCells[0].Value);
            //    //    string sql = "delete from tb_Test where ID='" + MMid + "'";
            //    //    BassClass.DeleteData(sql);
            //    //}
            if (tabControl1.SelectedTab.Name == "tabPage1")
            {
                if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow && this.dataGridView1.Rows[this.rowIndex].Selected)
                {
                    int MMid = Convert.ToInt32(dataGridView1.SelectedCells[0].Value);
                    string sql = "delete from tb_Test where ID='" + MMid + "'";
                    BassClass.DeleteData(sql);
                }
            }
            if (tabControl1.SelectedTab.Name == "tabPage2")
            {
                if (!this.dataGridView2.Rows[this.rowIndex2].IsNewRow && this.dataGridView2.Rows[this.rowIndex2].Selected)
                {
                    int MMid = Convert.ToInt32(dataGridView2.SelectedCells[0].Value);
                    string sql = "delete from tb_Test where ID='" + MMid + "'";
                    BassClass.DeleteData(sql);
                }
            }
            if (tabControl1.SelectedTab.Name == "tabPage3")
            {
                if (!this.dataGridView3.Rows[this.rowIndex3].IsNewRow && this.dataGridView3.Rows[this.rowIndex3].Selected)
                {
                    int MMid = Convert.ToInt32(dataGridView3.SelectedCells[0].Value);
                    string sql = "delete from tb_Test where ID='" + MMid + "'";
                    BassClass.DeleteData(sql);
                }
            }
        }

        private void 用户管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminStudent student = new frmAdminStudent();
            student.Show();
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0)
                {
                    this.dataGridView1.Rows[e.RowIndex].Selected = true;
                    rowIndex = e.RowIndex;
                    this.dataGridView1.CurrentCell = this.dataGridView1.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }

        private void dataGridView2_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0)
                {
                    this.dataGridView2.Rows[e.RowIndex].Selected = true;
                    rowIndex2 = e.RowIndex;
                    this.dataGridView2.CurrentCell = this.dataGridView2.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.dataGridView2, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }

        private void dataGridView3_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0)
                {
                    this.dataGridView3.Rows[e.RowIndex].Selected = true;
                    rowIndex3 = e.RowIndex;
                    this.dataGridView3.CurrentCell = this.dataGridView3.Rows[e.RowIndex].Cells[1];
                    this.contextMenuStrip1.Show(this.dataGridView3, e.Location);
                    contextMenuStrip1.Show(Cursor.Position);
                }
            }
        }

        private void 成绩查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminFindScore adminfindscore = new frmAdminFindScore();
            adminfindscore.Show();
        }

        private void 添加判断题ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminAddJudgeExam addjudeexam = new frmAdminAddJudgeExam();
            addjudeexam.Show();
        }

        private void 添加填空题ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAdminAddFillExam addfilleaxm = new frmAdminAddFillExam();
            addfilleaxm.Show();
        }

        private void 更改ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab.Name == "tabPage1")
            {
                if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow && this.dataGridView1.Rows[this.rowIndex].Selected)
                {
                    int MMid = Convert.ToInt32(dataGridView1.SelectedCells[0].Value);
                    string sql = "select * from tb_Test where ID='" + MMid + "'";
                    frmAdminAddSelectExam updateselectexam = new frmAdminAddSelectExam();
                    SqlConnection conn = BassClass.DBCon();
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    updateselectexam.mid = MMid;
                    updateselectexam.Timu = sdr["subject"].ToString();
                    updateselectexam.DaanA = sdr["A"].ToString();
                    updateselectexam.DaanB = sdr["B"].ToString();
                    updateselectexam.DaanC = sdr["C"].ToString();
                    updateselectexam.DaanD = sdr["D"].ToString();
                    updateselectexam.ZQDaan = sdr["rightkey"].ToString();
                    conn.Close();
                    updateselectexam.Show();
                }
            }
            if (tabControl1.SelectedTab.Name == "tabPage2")
            {
                if (!this.dataGridView2.Rows[this.rowIndex2].IsNewRow)
                {
                    int MMid = Convert.ToInt32(dataGridView2.SelectedCells[0].Value);
                    string sql = "select * from tb_Test where ID='" + MMid + "'";
                    frmAdminAddJudgeExam updatejudgeexam = new frmAdminAddJudgeExam();
                    SqlConnection conn = BassClass.DBCon();
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    updatejudgeexam.mid = MMid;
                    updatejudgeexam.timu = sdr["subject"].ToString();
                    updatejudgeexam.daan = sdr["rightkey"].ToString();
                    conn.Close();
                    updatejudgeexam.Show();
                }
            }
            if (tabControl1.SelectedTab.Name == "tabPage3")
            {
                if (!this.dataGridView3.Rows[this.rowIndex3].IsNewRow)
                {
                    int MMid = Convert.ToInt32(dataGridView3.SelectedCells[0].Value);
                    string sql = "select * from tb_Test where ID='" + MMid + "'";
                    frmAdminAddFillExam updatefillexam = new frmAdminAddFillExam();
                    SqlConnection conn = BassClass.DBCon();
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    updatefillexam.mid = MMid;
                    updatefillexam.timu = sdr["subject"].ToString();
                    updatefillexam.daan = sdr["rightkey"].ToString();
                    conn.Close();
                    updatefillexam.Show();
                }
            }
        }

        private void 退出系统ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void 注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
            new Form1().Show();
        }
    }
}
