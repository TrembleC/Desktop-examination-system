﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmUpdateUser : Form
    {
        public frmUpdateUser()
        {
            InitializeComponent();
        }
        public string leixing = "";
        public string userid = "";
        public string uname = "";
        public string password = "";
        public string isTest = "";
        public int mid;


        private void cbbusertype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmUpdateUser_Load(object sender, EventArgs e)
        {
            cbbusertype.Text = leixing;
            txtuserid.Text = userid;
            txtuser.Text = uname;
            txtpassword.Text = password;
            cbb_isTest.Text = isTest;
        }

        private void btn_updateUser_Click(object sender, EventArgs e)
        {
            int flag1;
            int flag2;
            if (cbbusertype.Text.Trim() == "学生")
                flag1 = 0;
            else
                flag1 = 1;
            if (cbb_isTest.Text.Trim() == "没有参加考试")
                flag2 = 0;
            else
                flag2 = 1;

            string sql = "update tb_User set UserFlag=" + flag1 + ",UserID='" + txtuserid.Text.Trim() + "',UserName='"
                + txtuser.Text.Trim() + "',UserPwd='" + txtpassword.Text.Trim() + "',IsTest=" + flag2 + " where id=" + mid;
            string sql2 = "update tb_ExamResult set UserID='" + txtuserid.Text.Trim() + "' where UserID='" + userid + "'";
            SqlConnection conn = BassClass.DBCon();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql2, conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
            BassClass.UpdateData(sql);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
