﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmAdminStudent : Form
    {
        public frmAdminStudent()
        {
            InitializeComponent();
        }
        public int rowIndex;
        SqlConnection conn = BassClass.DBCon();//创建联系
        private void getUserInfo()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select ID as '编号',UserFlag as '用户身份',UserName as '用户账号',UserID as '用户ID',UserPwd as '用户密码',IsTest as '是否考试',Name as '姓名',Tell as '联系方式',eMail as '邮箱',Birthday as '出生日期' from tb_User", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);//使用Fill方法填充ds
            dataGridView1.DataSource = ds.Tables[0];//设置数据源
            panel1.Dock = DockStyle.Fill;
            int width = dataGridView1.Width;
            int avgWidth = width / ds.Tables[0].Columns.Count;//求出每一列的header宽度
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                dataGridView1.Columns[i].Width = avgWidth;//设置每一列的宽度
            }
            
        }

        private void frmAdminStudent_Load(object sender, EventArgs e)
        {
            getUserInfo();
        }

        private void Add_user_Click(object sender, EventArgs e)
        {
            frmAddUser adduser = new frmAddUser();
            adduser.Show();
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            getUserInfo();
        }

        private void Update_user_Click(object sender, EventArgs e)
        {
            frmUpdateUser updateuser = new frmUpdateUser();
            if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow && this.dataGridView1.Rows[this.rowIndex].Selected)
            {
                int MMid = Convert.ToInt32(dataGridView1.SelectedCells[0].Value);
                string sql = "select * from tb_User where ID='" + MMid + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                string a = "";
                if (sdr.Read())
                {
                    a = sdr["UserFlag"].ToString();
                    if (a == "0")
                        updateuser.leixing = "学生";
                    else
                        updateuser.leixing = "教师";
                    updateuser.userid = sdr["UserID"].ToString();
                    updateuser.uname = sdr["UserName"].ToString();
                    updateuser.password = sdr["UserPwd"].ToString();
                    updateuser.mid = MMid;
                    string b = sdr["IsTest"].ToString();
                    if (b == "0")
                        updateuser.isTest = "没有参加考试";
                    else
                        updateuser.isTest = "已参加考试";
                    conn.Close();
                    updateuser.Show();
                }
            }
            else
            {
                MessageBox.Show("请选择用户！");
            }
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (e.RowIndex >= 0)
                {
                    this.dataGridView1.Rows[e.RowIndex].Selected = true;
                    rowIndex = e.RowIndex;
                    this.dataGridView1.CurrentCell = this.dataGridView1.Rows[e.RowIndex].Cells[1];
                }
            }
        }

        private void Delete_user_Click(object sender, EventArgs e)
        {
            if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow && this.dataGridView1.Rows[this.rowIndex].Selected)
            {
                if (MessageBox.Show("确定删除?", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    int Mid = Convert.ToInt32(dataGridView1.SelectedCells[0].Value);
                    string sql = "select UserID from tb_User where ID=" + Mid;
                    SqlConnection con = BassClass.DBCon();
                    con.Open();
                    SqlCommand com = new SqlCommand(sql, con);
                    string id = (string)com.ExecuteScalar();
                    con.Close();
                    sql = "delete from tb_ExamResult where UserID='" + id + "'";
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand(sql, conn);
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                    sql = "delete from tb_User where ID='" + Mid + "'";
                    BassClass.DeleteData(sql);
                    getUserInfo();
                }
                else
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show("请选择用户！");
            }
           
        }
    }
}
