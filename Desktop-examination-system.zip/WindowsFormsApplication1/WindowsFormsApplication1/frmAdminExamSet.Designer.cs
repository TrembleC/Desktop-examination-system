﻿namespace WindowsFormsApplication1
{
    partial class frmAdminExamSet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cbbxz = new System.Windows.Forms.ComboBox();
            this.cbbpd = new System.Windows.Forms.ComboBox();
            this.cbbtk = new System.Windows.Forms.ComboBox();
            this.cbbxzfz = new System.Windows.Forms.ComboBox();
            this.cbbpdfz = new System.Windows.Forms.ComboBox();
            this.cbbtkfz = new System.Windows.Forms.ComboBox();
            this.kstime = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(88, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "选择题比例：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(88, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "判断题比例：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(88, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "填空题比例：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(262, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(15, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(262, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(15, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "%";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(262, 243);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "%";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(318, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "选择题分值：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Location = new System.Drawing.Point(318, 148);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "判断题分值:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Location = new System.Drawing.Point(318, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "填空题分值：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(505, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "考试总时间：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(682, 48);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "分钟";
            // 
            // cbbxz
            // 
            this.cbbxz.FormattingEnabled = true;
            this.cbbxz.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.cbbxz.Location = new System.Drawing.Point(193, 44);
            this.cbbxz.Name = "cbbxz";
            this.cbbxz.Size = new System.Drawing.Size(63, 23);
            this.cbbxz.TabIndex = 11;
            this.cbbxz.SelectedIndexChanged += new System.EventHandler(this.cbbxz_SelectedIndexChanged);
            // 
            // cbbpd
            // 
            this.cbbpd.FormattingEnabled = true;
            this.cbbpd.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.cbbpd.Location = new System.Drawing.Point(193, 144);
            this.cbbpd.Name = "cbbpd";
            this.cbbpd.Size = new System.Drawing.Size(63, 23);
            this.cbbpd.TabIndex = 12;
            this.cbbpd.SelectedIndexChanged += new System.EventHandler(this.cbbpd_SelectedIndexChanged);
            // 
            // cbbtk
            // 
            this.cbbtk.FormattingEnabled = true;
            this.cbbtk.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.cbbtk.Location = new System.Drawing.Point(193, 239);
            this.cbbtk.Name = "cbbtk";
            this.cbbtk.Size = new System.Drawing.Size(63, 23);
            this.cbbtk.TabIndex = 13;
            // 
            // cbbxzfz
            // 
            this.cbbxzfz.FormattingEnabled = true;
            this.cbbxzfz.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbbxzfz.Location = new System.Drawing.Point(421, 44);
            this.cbbxzfz.Name = "cbbxzfz";
            this.cbbxzfz.Size = new System.Drawing.Size(67, 23);
            this.cbbxzfz.TabIndex = 14;
            // 
            // cbbpdfz
            // 
            this.cbbpdfz.FormattingEnabled = true;
            this.cbbpdfz.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbbpdfz.Location = new System.Drawing.Point(421, 144);
            this.cbbpdfz.Name = "cbbpdfz";
            this.cbbpdfz.Size = new System.Drawing.Size(66, 23);
            this.cbbpdfz.TabIndex = 15;
            // 
            // cbbtkfz
            // 
            this.cbbtkfz.FormattingEnabled = true;
            this.cbbtkfz.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbbtkfz.Location = new System.Drawing.Point(421, 239);
            this.cbbtkfz.Name = "cbbtkfz";
            this.cbbtkfz.Size = new System.Drawing.Size(66, 23);
            this.cbbtkfz.TabIndex = 16;
            // 
            // kstime
            // 
            this.kstime.Location = new System.Drawing.Point(599, 43);
            this.kstime.Name = "kstime";
            this.kstime.Size = new System.Drawing.Size(67, 25);
            this.kstime.TabIndex = 17;
            this.kstime.KeyDown += new System.Windows.Forms.KeyEventHandler(this.kstime_KeyDown);
            this.kstime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.kstime_KeyPress);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Location = new System.Drawing.Point(508, 148);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 18;
            this.button1.Text = "确定";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(644, 148);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 30);
            this.button2.TabIndex = 19;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmAdminExamSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(820, 325);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.kstime);
            this.Controls.Add(this.cbbtkfz);
            this.Controls.Add(this.cbbpdfz);
            this.Controls.Add(this.cbbxzfz);
            this.Controls.Add(this.cbbtk);
            this.Controls.Add(this.cbbpd);
            this.Controls.Add(this.cbbxz);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAdminExamSet";
            this.Text = "考试设置";
            this.Load += new System.EventHandler(this.frmAdminExamSet_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbbxz;
        private System.Windows.Forms.ComboBox cbbpd;
        private System.Windows.Forms.ComboBox cbbtk;
        private System.Windows.Forms.ComboBox cbbxzfz;
        private System.Windows.Forms.ComboBox cbbpdfz;
        private System.Windows.Forms.ComboBox cbbtkfz;
        private System.Windows.Forms.TextBox kstime;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}