﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmAdminAddJudgeExam : Form
    {
        public frmAdminAddJudgeExam()
        {
            InitializeComponent();
        }
        public string timu = "";
        public string daan = "";
        public int mid;

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (txttimu.Text.Trim() == "" || cbb_daan.Text.Trim() == "请选择答案")
            {
                MessageBox.Show("提示：请将信息填写完整！", "警告");
            }
            else if(timu !=""||daan!="")
            {
                string result = "";
                if (cbb_daan.Text.Trim() == "正确")
                    result = "1";
                else
                    result = "0";
                string sql = "update tb_Test set subject='" + txttimu.Text.Trim() + "',rightkey='" + result + "' where ID=" + mid;
                BassClass.UpdateData(sql);
                this.Close();
            }
            else
            {
           
                    string result = "";
                    if (cbb_daan.Text.Trim() == "正确")
                        result = "1";
                    else
                        result = "0";
                    string sql = "insert into tb_Test(TypeID,subject,rightkey) values(2,'" + txttimu.Text.Trim() + "','" + result + "')";
                    BassClass.InsertData(sql);
                    txttimu.Text = "";
                    cbb_daan.SelectedIndex = 0;

            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmAdminAddJudgeExam_Load(object sender, EventArgs e)
        {
            if (daan == "1")
                cbb_daan.Text = "正确";
            else
                cbb_daan.Text = "错误";
            txttimu.Text = timu;
        }

        private void cbb_daan_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
