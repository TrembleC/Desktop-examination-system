﻿namespace WindowsFormsApplication1
{
    partial class frmAdminFindScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_cxtj = new System.Windows.Forms.GroupBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.txtKey = new System.Windows.Forms.TextBox();
            this.labKeyValue = new System.Windows.Forms.Label();
            this.cbbSC = new System.Windows.Forms.ComboBox();
            this.labSelectCondition = new System.Windows.Forms.Label();
            this.gb_result = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gb_cxtj.SuspendLayout();
            this.gb_result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // gb_cxtj
            // 
            this.gb_cxtj.BackColor = System.Drawing.Color.Transparent;
            this.gb_cxtj.Controls.Add(this.btnQuery);
            this.gb_cxtj.Controls.Add(this.txtKey);
            this.gb_cxtj.Controls.Add(this.labKeyValue);
            this.gb_cxtj.Controls.Add(this.cbbSC);
            this.gb_cxtj.Controls.Add(this.labSelectCondition);
            this.gb_cxtj.Dock = System.Windows.Forms.DockStyle.Top;
            this.gb_cxtj.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gb_cxtj.Location = new System.Drawing.Point(0, 0);
            this.gb_cxtj.Name = "gb_cxtj";
            this.gb_cxtj.Size = new System.Drawing.Size(701, 153);
            this.gb_cxtj.TabIndex = 0;
            this.gb_cxtj.TabStop = false;
            this.gb_cxtj.Text = "查询条件：";
            // 
            // btnQuery
            // 
            this.btnQuery.BackColor = System.Drawing.Color.LightGray;
            this.btnQuery.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnQuery.Location = new System.Drawing.Point(598, 64);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(75, 39);
            this.btnQuery.TabIndex = 4;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = false;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // txtKey
            // 
            this.txtKey.Location = new System.Drawing.Point(437, 70);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(121, 27);
            this.txtKey.TabIndex = 3;
            // 
            // labKeyValue
            // 
            this.labKeyValue.AutoSize = true;
            this.labKeyValue.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labKeyValue.Location = new System.Drawing.Point(286, 74);
            this.labKeyValue.Name = "labKeyValue";
            this.labKeyValue.Size = new System.Drawing.Size(129, 19);
            this.labKeyValue.TabIndex = 2;
            this.labKeyValue.Text = "输入关键字：";
            // 
            // cbbSC
            // 
            this.cbbSC.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbbSC.FormattingEnabled = true;
            this.cbbSC.Items.AddRange(new object[] {
            "请选择查询条件",
            "用户ID",
            "用户名"});
            this.cbbSC.Location = new System.Drawing.Point(143, 72);
            this.cbbSC.Name = "cbbSC";
            this.cbbSC.Size = new System.Drawing.Size(121, 23);
            this.cbbSC.TabIndex = 1;
            this.cbbSC.Text = "请选择查询条件";
            // 
            // labSelectCondition
            // 
            this.labSelectCondition.AutoSize = true;
            this.labSelectCondition.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labSelectCondition.Location = new System.Drawing.Point(12, 74);
            this.labSelectCondition.Name = "labSelectCondition";
            this.labSelectCondition.Size = new System.Drawing.Size(109, 19);
            this.labSelectCondition.TabIndex = 0;
            this.labSelectCondition.Text = "查询条件：";
            // 
            // gb_result
            // 
            this.gb_result.BackColor = System.Drawing.Color.Transparent;
            this.gb_result.Controls.Add(this.dataGridView1);
            this.gb_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gb_result.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gb_result.Location = new System.Drawing.Point(0, 153);
            this.gb_result.Name = "gb_result";
            this.gb_result.Size = new System.Drawing.Size(701, 365);
            this.gb_result.TabIndex = 1;
            this.gb_result.TabStop = false;
            this.gb_result.Text = "查询结果";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(695, 339);
            this.dataGridView1.TabIndex = 0;
            // 
            // frmAdminFindScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(701, 518);
            this.Controls.Add(this.gb_result);
            this.Controls.Add(this.gb_cxtj);
            this.Name = "frmAdminFindScore";
            this.Text = "查询分数";
            this.gb_cxtj.ResumeLayout(false);
            this.gb_cxtj.PerformLayout();
            this.gb_result.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_cxtj;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.TextBox txtKey;
        private System.Windows.Forms.Label labKeyValue;
        private System.Windows.Forms.ComboBox cbbSC;
        private System.Windows.Forms.Label labSelectCondition;
        private System.Windows.Forms.GroupBox gb_result;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}