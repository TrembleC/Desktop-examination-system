﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class frmStudentExam : Form
    {
        public frmStudentExam()
        {
            InitializeComponent();
        }
        public string Username = "";
        public string Userpwd = "";
        public string UserId = "";
        SqlConnection conn = BassClass.DBCon();

        private void checkIsTest()
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select IsTest from tb_User where UserName='" + Username + "'", conn);
                string flag = cmd.ExecuteScalar().ToString();
                if(flag=="0")
                {
                    开始考试ToolStripMenuItem.Enabled = true;
                    查询分数ToolStripMenuItem.Enabled = false;
                }
                else
                {
                    开始考试ToolStripMenuItem.Enabled = false;
                   查询分数ToolStripMenuItem.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            
        }

        private void frmStudentExam_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "当前用户：" + Username;
            checkIsTest();

            conn.Open();
            SqlCommand com = new SqlCommand("select UserID from tb_User where UserName='" + Username
                + "'and UserFlag='0'", conn);
            UserId = (string)com.ExecuteScalar();
            conn.Close();
        }

        private void 注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
            new Form1().Show();
        }

        private void 查询分数ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from tb_ExamResult where UserId='" + UserId + "'", conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                string xz = sdr[2].ToString();
                string pd = sdr[3].ToString();
                string tk = sdr[4].ToString();
                string all = sdr[5].ToString();

                MessageBox.Show(Username + "你好,你的考分如下：\n" + "选择题得分：" + xz + "\n判断题得分：" + pd
                    + "\n填空题得分：" + tk + "\n总分：" + all);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void 开始考试ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmStartExam startexam = new frmStartExam();
            startexam.username = Username;
            startexam.userId = UserId;
            startexam.userPAssword = Userpwd;
            startexam.Show();
        }

        private void 退出系统OToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void 修改密码PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdatePassword updatepassword = new frmUpdatePassword();
            updatepassword.updateUsername = Username;
            updatepassword.updatePassWord = Userpwd;
            updatepassword.updateUserId = UserId;
            updatepassword.Show();
        }

        private void 个人信息ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmInformation updatepassword = new frmInformation();
            updatepassword.updateUsername = Username;
            updatepassword.updatePassWord = Userpwd;
            updatepassword.updateUserId = UserId;
            updatepassword.Show();
        }
    }
}
