﻿namespace WindowsFormsApplication1
{
    partial class frmAddUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_AddUser = new System.Windows.Forms.Button();
            this.cbb_isTest = new System.Windows.Forms.ComboBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.txtuserid = new System.Windows.Forms.TextBox();
            this.cbbusertype = new System.Windows.Forms.ComboBox();
            this.IsTest = new System.Windows.Forms.Label();
            this.pwd = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.lx = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.btn_AddUser);
            this.groupBox1.Controls.Add(this.cbb_isTest);
            this.groupBox1.Controls.Add(this.txtpassword);
            this.groupBox1.Controls.Add(this.txtuser);
            this.groupBox1.Controls.Add(this.txtuserid);
            this.groupBox1.Controls.Add(this.cbbusertype);
            this.groupBox1.Controls.Add(this.IsTest);
            this.groupBox1.Controls.Add(this.pwd);
            this.groupBox1.Controls.Add(this.username);
            this.groupBox1.Controls.Add(this.name);
            this.groupBox1.Controls.Add(this.lx);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.Size = new System.Drawing.Size(477, 558);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "添加新用户";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Location = new System.Drawing.Point(250, 467);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 58);
            this.button2.TabIndex = 11;
            this.button2.Text = "取消";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.BackColor = System.Drawing.Color.LightGray;
            this.btn_AddUser.Location = new System.Drawing.Point(82, 467);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Size = new System.Drawing.Size(103, 58);
            this.btn_AddUser.TabIndex = 10;
            this.btn_AddUser.Text = "确定";
            this.btn_AddUser.UseVisualStyleBackColor = false;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // cbb_isTest
            // 
            this.cbb_isTest.FormattingEnabled = true;
            this.cbb_isTest.Items.AddRange(new object[] {
            "没有参加考试",
            "已参加考试"});
            this.cbb_isTest.Location = new System.Drawing.Point(199, 379);
            this.cbb_isTest.Name = "cbb_isTest";
            this.cbb_isTest.Size = new System.Drawing.Size(154, 28);
            this.cbb_isTest.TabIndex = 9;
            this.cbb_isTest.Text = "没有参加考试";
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(142, 306);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(211, 30);
            this.txtpassword.TabIndex = 8;
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(142, 233);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(211, 30);
            this.txtuser.TabIndex = 7;
            // 
            // txtuserid
            // 
            this.txtuserid.Location = new System.Drawing.Point(160, 160);
            this.txtuserid.Name = "txtuserid";
            this.txtuserid.Size = new System.Drawing.Size(193, 30);
            this.txtuserid.TabIndex = 6;
            // 
            // cbbusertype
            // 
            this.cbbusertype.FormattingEnabled = true;
            this.cbbusertype.Items.AddRange(new object[] {
            "学生",
            "教师"});
            this.cbbusertype.Location = new System.Drawing.Point(142, 89);
            this.cbbusertype.Name = "cbbusertype";
            this.cbbusertype.Size = new System.Drawing.Size(211, 28);
            this.cbbusertype.TabIndex = 5;
            this.cbbusertype.Text = "学生";
            // 
            // IsTest
            // 
            this.IsTest.AutoSize = true;
            this.IsTest.BackColor = System.Drawing.Color.Transparent;
            this.IsTest.Location = new System.Drawing.Point(78, 385);
            this.IsTest.Name = "IsTest";
            this.IsTest.Size = new System.Drawing.Size(129, 20);
            this.IsTest.TabIndex = 4;
            this.IsTest.Text = "是否已考试：";
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.BackColor = System.Drawing.Color.Transparent;
            this.pwd.Location = new System.Drawing.Point(78, 311);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(69, 20);
            this.pwd.TabIndex = 3;
            this.pwd.Text = "密码：";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.Location = new System.Drawing.Point(78, 237);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(69, 20);
            this.username.TabIndex = 2;
            this.username.Text = "账号：";
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.Location = new System.Drawing.Point(78, 163);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(89, 20);
            this.name.TabIndex = 1;
            this.name.Text = "用户ID：";
            // 
            // lx
            // 
            this.lx.AutoSize = true;
            this.lx.BackColor = System.Drawing.Color.Transparent;
            this.lx.Location = new System.Drawing.Point(78, 89);
            this.lx.Name = "lx";
            this.lx.Size = new System.Drawing.Size(69, 20);
            this.lx.TabIndex = 0;
            this.lx.Text = "类型：";
            // 
            // frmAddUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(477, 558);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmAddUser";
            this.Text = "用户管理-添加新用户";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_AddUser;
        private System.Windows.Forms.ComboBox cbb_isTest;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.TextBox txtuserid;
        private System.Windows.Forms.ComboBox cbbusertype;
        private System.Windows.Forms.Label IsTest;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label lx;
    }
}