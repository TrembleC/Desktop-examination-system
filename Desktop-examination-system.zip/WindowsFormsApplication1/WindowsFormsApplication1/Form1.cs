﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text.Trim() == "请选择登录身份")
            {
                MessageBox.Show("请选择登录身份！");
            }
            else
            {
                if (txtUser.Text.Trim() == "" || txtPwd.Text.Trim() == "")
                {
                    MessageBox.Show("请输入用户帐号和密码！");
                }
                else
                {
                    if (comboBox1.Text.Trim() == "学生")
                    {
                        SqlConnection conn = BassClass.DBCon();
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("select * from tb_User where UserFlag=0 and UserName='" + txtUser.Text.Trim() + "'and UserPwd='" + txtPwd.Text.Trim() + "'", conn);
                        SqlDataReader sdr = cmd.ExecuteReader();
                        sdr.Read();
                        if (sdr.HasRows)
                        {
                            this.Hide();
                            frmStudentExam studentexam = new frmStudentExam();
                            studentexam.Username = txtUser.Text.Trim();
                            studentexam.Userpwd = txtPwd.Text.Trim();
                            studentexam.Show();
                        }
                        else
                        {
                            MessageBox.Show("学生用户名或密码错误！");
                        }
                        conn.Close();
                    }
                    else
                    {
                        SqlConnection conn = BassClass.DBCon();
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("select * from tb_User where UserFlag=1 and UserName='" + txtUser.Text.Trim() + "'and UserPwd='" + txtPwd.Text.Trim() + "'", conn);
                        SqlDataReader sdr = cmd.ExecuteReader();
                        sdr.Read();
                        if (sdr.HasRows)
                        {
                            this.Hide();
                            frmAdminManage studentexam = new frmAdminManage();
                            studentexam.Username = txtUser.Text.Trim();
                            studentexam.Show();
                        }
                        else
                        {
                            MessageBox.Show("管理员用户名或密码错误！");
                        }
                        conn.Close();
                    }
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtUser.Text = "";
            txtPwd.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            register r = new register();
            r.Show();
        }

        private void txtPwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                button1_Click(sender, e);
            }
        }
    }
}
