﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            regPwd.Text = "";
            regUser.Text = "";
            msPwd.Text = "";
            UserId.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (regPwd.Text.Trim() == "" || regUser.Text.Trim() == ""||msPwd.Text.Trim()=="" || UserId.Text.Trim() == "")
            {
                MessageBox.Show("请补全注册信息！");
            }
            else
            {
                if (regPwd.Text.Trim() != msPwd.Text.Trim())
                {
                    MessageBox.Show("密码不一致！");
                }
                else
                {
                    SqlConnection conn = BassClass.DBCon();
                    try
                    {
                        conn.Open();
                        SqlCommand com = new SqlCommand("select * from tb_User where (UserName='" + regUser.Text.Trim()
                            + "'or UserID='" + UserId.Text.Trim() + "')and UserFlag = 0", conn);
                        object obj = com.ExecuteScalar();
                        if (obj != null)
                        {
                            MessageBox.Show("用户名或用户ID已存在！请重新输入");
                            obj = null;
                        }
                        else
                        {
                            string Sql = "insert tb_User (Userflag,UserName,UserID,UserPwd,IsTest) values(0,'"
                                + regUser.Text.Trim() + "','" + UserId.Text.Trim() + "','" + regPwd.Text.Trim() + "',0)";
                            string sql2 = "insert tb_ExamResult(UserID)values('" + UserId.Text.Trim() + "')";
                            SqlCommand cmd = new SqlCommand(Sql, conn);
                            SqlCommand cmd2 = new SqlCommand(sql2, conn);
                            cmd.ExecuteNonQuery();
                            cmd2.ExecuteNonQuery();
                            MessageBox.Show("注册成功！");
                            this.Dispose();
                            new Form1().Show();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("注册失败" + ex.Message.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void register_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Dispose();
            new Form1().Show();
        }
    }
}
